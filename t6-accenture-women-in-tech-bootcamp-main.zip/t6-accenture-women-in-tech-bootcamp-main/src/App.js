import './styles/App.css';
import { Routes, Route } from 'react-router-dom'
import Startpage from './pages/Startpage';
import Homepage from './pages/Homepage';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Chatbot from './pages/Chatbot';
import Levels from './pages/Levels';
import Lessonstart from './pages/Lessonstart';
import Lessons from './pages/Lessons';

import Quiz1 from './pages/Quiz1';
import Quiz2 from './pages/Quiz2';
import Quiz3 from './pages/Quiz3';
import Quiz4 from './pages/Quiz4';
import Quiz5 from './pages/Quiz5';

import Quizcompleted from './pages/Quizcompleted.js';
import Quizfailed from './pages/Quizfailed';

function App() {
  return (
    <Routes>
       <Route path="/" element={<Startpage />}/>
       <Route path="/homepage" element={<Homepage />}/>
       <Route path="/login" element={<Login />}/>
       <Route path="/signup" element={<Signup />}/>
       <Route path="/chatbot" element={<Chatbot />}/>
       <Route path="/levels" element={<Levels />}/>
       <Route path="/lessonstart" element={<Lessonstart/>}/>
       <Route path="/lessons" element={<Lessons/>}/>

       <Route path="/quiz1" element={<Quiz1/>}/>
       <Route path="/quiz2" element={<Quiz2/>}/>
       <Route path="/quiz3" element={<Quiz3/>}/>
       <Route path="/quiz4" element={<Quiz4/>}/>
       <Route path="/quiz5" element={<Quiz5/>}/>

       <Route path="/quizcompleted" element={<Quizcompleted/>}/>
       <Route path="/quizfailed" element={<Quizfailed/>}/>
    </Routes>
  );
}

export default App;
