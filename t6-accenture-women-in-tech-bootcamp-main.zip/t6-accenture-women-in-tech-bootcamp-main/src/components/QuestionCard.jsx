import '../styles/App.css';
import React from 'react';


const QuestionCard = ({ questionno, question, answers, link}) => {
    return (
        
        <div className='card'>
            <div className='card-header'>
                <h2>{questionno}</h2>
            </div>

            <div className='question-content'>
                <div className='question'>
                    <p>{question}</p>
                </div>
            </div>
        </div>
    )
}

export default QuestionCard;