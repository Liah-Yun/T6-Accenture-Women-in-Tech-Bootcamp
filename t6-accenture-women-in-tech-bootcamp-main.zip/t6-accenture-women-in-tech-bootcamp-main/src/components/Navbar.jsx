import '../styles/App.css';
import logo from '../Assets/Flower.png';
import React from 'react';


const NavBar = () => {
    return (
        <nav className='Navbar'>
            <div>
                <img src={logo} alt='logo' />
            </div>

            <div className='Menubar'>
                <ul>
                    <li className='Menuitem'><a href='http://localhost:3001/homepage'>Dashboard</a></li>
                    <li className='Menuitem'><a href='http://localhost:3001/levels'>Levels</a></li>
                    <li className='Menuitem'><a href='http://localhost:3001/lessonstart'>Lessons</a></li>
                    <li className='Menuitem'><a href='http://localhost:3001/chatbot'>Chatbot</a></li>
                </ul>
            </div>

            <a className='Button1' href='http://localhost:3001/login'>Login</a>
        </nav>
    )
}

export default NavBar;