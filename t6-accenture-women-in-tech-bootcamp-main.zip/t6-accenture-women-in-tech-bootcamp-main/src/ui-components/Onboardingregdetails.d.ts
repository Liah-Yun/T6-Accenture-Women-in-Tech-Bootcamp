/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type OnboardingregdetailsOverridesProps = {
    Onboardingregdetails?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "What is your Annual Income?"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 8"?: PrimitiveOverrideProps<ViewProps>;
    "What is your Age?"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 9"?: PrimitiveOverrideProps<ViewProps>;
    "What is your Current Super Balance?"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 11"?: PrimitiveOverrideProps<ViewProps>;
    "What is your Current Employer Contribution?"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 10"?: PrimitiveOverrideProps<ViewProps>;
    "Desired Retirement Age?"?: PrimitiveOverrideProps<TextProps>;
    "ENTER YOUR DETAILS"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type OnboardingregdetailsProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: OnboardingregdetailsOverridesProps | undefined | null;
}>;
export default function Onboardingregdetails(props: OnboardingregdetailsProps): React.ReactElement;
