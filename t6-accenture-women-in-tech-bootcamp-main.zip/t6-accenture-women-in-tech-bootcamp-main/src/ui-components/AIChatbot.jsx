/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function AIChatbot(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="926px"
      height="428px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "AIChatbot")}
      {...rest}
    >
      <View
        width="720px"
        height="46px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="789.75px"
        left="432.14px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 6")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="13px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="488px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="250.43px"
        left="300.31px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
        {...getOverrideProps(
          overrides,
          "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
        )}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="343.29px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="755.73px"
        left="53.95px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 6")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="186.88px"
          {...getOverrideProps(overrides, "Button25478")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(229,229,229,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(255,255,255,1)"
            {...getOverrideProps(overrides, "Rectangle25479")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="13px"
            fontWeight="700"
            color="rgba(28,176,246,1)"
            textTransform="uppercase"
            lineHeight="18px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="116.15px"
            height="11.75px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="11.75px"
            left="20.13px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Continue to next lesson"
            {...getOverrideProps(overrides, "Continue to next lesson")}
          ></Text>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button25481")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(109,199,249,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle25482")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="18px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="67.85px"
            height="11.75px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="11.75px"
            left="44.28px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Next Question "
            {...getOverrideProps(overrides, "Next Question")}
          ></Text>
        </View>
      </View>
      <Icon
        width="34px"
        height="35px"
        viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
        paths={[
          {
            d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
            fill: "rgba(252,197,26,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="764px"
        left="384px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Star 1")}
      ></Icon>
      <View
        width="433px"
        height="32px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="-4.85px"
        left="925.97px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 28")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="61.17px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="367.18px"
        left="920.92px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 15")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button58556")}
        >
          <View
            width="50.6px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(206,72,42,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(206,72,42,1)"
            {...getOverrideProps(overrides, "Rectangle58557")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="45.17px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="4.47px"
            left="16px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="EXIT"
            {...getOverrideProps(overrides, "EXIT")}
          ></Text>
        </View>
      </View>
      <View
        width="356px"
        height="82px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="60.42px"
        left="111.31px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 30")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="15px"
        fontWeight="700"
        color="rgba(255,255,255,1)"
        textTransform="capitalize"
        lineHeight="25px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="286px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="108.56px"
        left="83.56px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Type your question..."
        {...getOverrideProps(overrides, "Type your question...")}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="290px"
        height="95px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="429.15px"
        left="736.24px"
        transformOrigin="top left"
        transform="rotate(-90.3deg)"
        {...getOverrideProps(overrides, "Group 8")}
      >
        <Icon
          width="258.13px"
          height="95px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 258.126953125,
            height: 94.99998474121094,
          }}
          paths={[
            {
              d: "M6.81975e-15 39.9935C1.07534e-14 17.9021 17.9086 0 40 0L218.127 0C240.218 0 258.127 17.9086 258.127 40L258.127 55C258.127 77.0914 240.218 95 218.127 95L35.7265 95C15.9953 95 -1.06309e-14 79.0047 0 59.2735L0 59.2735C3.62344e-15 52.5483 5.74003e-15 46.0572 6.81975e-15 39.9935Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="31.87px"
          {...getOverrideProps(overrides, "Rectangle 858609")}
        ></Icon>
        <Icon
          width="26.02px"
          height="38.8px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 39.12060546875,
            height: 26.396583557128906,
          }}
          paths={[
            {
              d: "M12.9226 2.58432C13.7318 17.0048 15.664 24.9939 26.0182 38.7955L0 38.7955C0 38.7955 12.1135 -11.8361 12.9226 2.58432Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="60.99px"
          left="0.33px"
          transformOrigin="top left"
          transform="rotate(-90.72deg)"
          {...getOverrideProps(overrides, "Polygon 158610")}
        ></Icon>
        <Text
          fontFamily="Inter"
          fontSize="10px"
          fontWeight="500"
          color="rgba(0,0,0,1)"
          textTransform="capitalize"
          lineHeight="25px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="230.66px"
          height="55.84px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="20px"
          left="276px"
          transformOrigin="top left"
          transform="rotate(180deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="I’m just about to get my first job, what should I know about Super?"
          {...getOverrideProps(
            overrides,
            "I\u2019m just about to get my first job, what should I know about Super?"
          )}
        ></Text>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="341px"
        height="117px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="-4.56px"
        left="870.98px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 7")}
      >
        <Icon
          width="303.52px"
          height="117px"
          viewBox={{ minX: 0, minY: 0, width: 303.52197265625, height: 117 }}
          paths={[
            {
              d: "M9.02186e-15 39.9894C1.00627e-14 17.898 17.9086 0 40 0L263.522 0C285.614 0 303.522 17.9086 303.522 40L303.522 77C303.522 99.0914 285.614 117 263.522 117L40 117C17.9086 117 -1.24537e-14 99.1011 -1.98313e-15 77.0097C-1.36949e-15 75.715 -7.09299e-16 74.3789 0 73C6.0812e-15 61.1784 8.55287e-15 49.9439 9.02186e-15 39.9894Z",
              fill: "rgba(243,243,243,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="37.48px"
          {...getOverrideProps(overrides, "Rectangle 858602")}
        ></Icon>
        <Icon
          width="32.04px"
          height="45.62px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 46.0009765625,
            height: 32.50947570800781,
          }}
          paths={[
            {
              d: "M15.9151 3.03883C16.9116 19.9954 19.2914 29.3895 32.0433 45.6184L0 45.6184C0 45.6184 14.9187 -13.9178 15.9151 3.03883Z",
              fill: "rgba(243,243,243,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="75.11px"
          left="0.38px"
          transformOrigin="top left"
          transform="rotate(-90.69deg)"
          {...getOverrideProps(overrides, "Polygon 158603")}
        ></Icon>
        <Text
          fontFamily="Inter"
          fontSize="11px"
          fontWeight="500"
          color="rgba(0,0,0,1)"
          textTransform="capitalize"
          lineHeight="25px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="255.32px"
          height="68.78px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="23.72px"
          left="61.45px"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Hi, I’m your SuperSavvy AI Assist, Please type in any question you have about superannuation :) "
          {...getOverrideProps(
            overrides,
            "Hi, I\u2019m your SuperSavvy AI Assist, Please type in any question you have about superannuation :)"
          )}
        ></Text>
      </View>
      <Image
        width="29px"
        height="69px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="16.47px"
        left="101.07px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(
          overrides,
          "Professional Financial Investment Company and Success Symbol Logo 3"
        )}
      ></Image>
    </View>
  );
}
