/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz01OverridesProps = {
    Quiz01?: PrimitiveOverrideProps<ViewProps>;
    "Quiz 1"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 2125199"?: PrimitiveOverrideProps<ViewProps>;
    "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25207?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25208?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    "Group 1"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 6"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    Character_1_Standing?: PrimitiveOverrideProps<ImageProps>;
    "Group 10"?: PrimitiveOverrideProps<ViewProps>;
    Button25499?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25500?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 11"?: PrimitiveOverrideProps<ViewProps>;
    Button25524?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25525?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 2125201"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 22"?: PrimitiveOverrideProps<ViewProps>;
    TRUE?: PrimitiveOverrideProps<TextProps>;
    FALSE?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type Quiz01Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz01OverridesProps | undefined | null;
}>;
export default function Quiz01(props: Quiz01Props): React.ReactElement;
