/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import { createTheme, defaultTheme } from "@aws-amplify/ui-react";
export default createTheme(defaultTheme);
