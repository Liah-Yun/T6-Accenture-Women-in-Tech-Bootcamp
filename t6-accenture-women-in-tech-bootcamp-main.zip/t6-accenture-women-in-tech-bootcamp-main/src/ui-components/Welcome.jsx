/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function Welcome(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="500px"
      height="285.61px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Welcome")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="360px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="87.88%"
        bottom="0%"
        left="15%"
        right="13%"
        {...getOverrideProps(overrides, "Group 6")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="173.12px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="51.91%"
          right="0%"
          {...getOverrideProps(overrides, "Button58566")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0%"
            bottom="0%"
            left="0%"
            right="9.65%"
            border="1px SOLID rgba(229,229,229,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(255,255,255,1)"
            {...getOverrideProps(overrides, "Rectangle58567")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(28,176,246,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="145px"
            height="12px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="34.67%"
            bottom="30.66%"
            left="16.24%"
            right="0%"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="START FIRST LESSON"
            {...getOverrideProps(overrides, "START FIRST LESSON")}
          ></Text>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="56.55%"
          {...getOverrideProps(overrides, "Button58569")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0%"
            bottom="0%"
            left="0%"
            right="0%"
            border="1px SOLID rgba(109,199,249,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle58570")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="102px"
            height="12px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="34.67%"
            bottom="30.66%"
            left="28.13%"
            right="6.65%"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="VIEW ALL LESSONS"
            {...getOverrideProps(overrides, "VIEW ALL LESSONS")}
          ></Text>
        </View>
      </View>
      <View
        width="500px"
        height="183px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="35.93%"
        left="0%"
        right="0%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 26")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="500"
        color="rgba(0,0,0,1)"
        textTransform="capitalize"
        lineHeight="25px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="390.69px"
        height="112.87px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="12.6%"
        bottom="47.88%"
        left="12%"
        right="9.86%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided  "
        {...getOverrideProps(
          overrides,
          "Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided"
        )}
      ></Text>
    </View>
  );
}
