/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function Quiz03(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="928.23px"
      height="432.84px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Quiz03")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="98.88%"
        bottom="-212.81%"
        left="0%"
        right="53.89%"
        transformOrigin="top left"
        transform="rotate(-89.7deg)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Quiz 3")}
      >
        <View
          width="926px"
          height="32px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="-0.24px"
          left="428px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 2625312")}
        ></View>
        <View
          padding="0px 0px 0px 0px"
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="194.05px"
          left="372.02px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 8")}
        >
          <View
            width="587px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(240,240,240,1)"
            {...getOverrideProps(overrides, "Rectangle 625223")}
          ></View>
          <View
            width="339px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle 7")}
          ></View>
        </View>
        <View
          width="720px"
          height="46px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="789.75px"
          left="432.14px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 625297")}
        ></View>
        <View
          width="520px"
          height="121px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="234.3px"
          left="325.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 21")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="13px"
          fontWeight="600"
          color="rgba(255,255,255,1)"
          lineHeight="30px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0px"
          width="404px"
          height="191px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="292.43px"
          left="300.53px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="How much do you have to earn per month before tax to be entitled for Super?"
          {...getOverrideProps(
            overrides,
            "How much do you have to earn per month before tax to be entitled for Super?"
          )}
        ></Text>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="755.76px"
          left="46.95px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 6")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25304")}
          >
            <View
              width="156.4px"
              height="34.61px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(109,199,249,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(43,175,231,1)"
              {...getOverrideProps(overrides, "Rectangle25305")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="18px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              letterSpacing="0.65px"
              width="67.85px"
              height="11.75px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="11.75px"
              left="44.28px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="Next Question "
              {...getOverrideProps(overrides, "Next Question")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="7.8px"
          left="421.04px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 9")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="61.17px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25491")}
          >
            <View
              width="50.6px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(206,72,42,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(206,72,42,1)"
              {...getOverrideProps(overrides, "Rectangle25492")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="45.17px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="4.47px"
              left="16px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="EXIT"
              {...getOverrideProps(overrides, "EXIT")}
            ></Text>
          </View>
        </View>
        <Icon
          width="34px"
          height="35px"
          viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
          paths={[
            {
              d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
              fill: "rgba(252,197,26,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="764px"
          left="384px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Star 1")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.02px"
          left="188.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 6")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.23px"
          left="148.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 7")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.44px"
          left="108.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 8")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.64px"
          left="70.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 9")}
        ></Icon>
        <View
          width="470px"
          height="22px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="270px"
          left="191.41px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(243,243,243,1)"
          {...getOverrideProps(overrides, "Rectangle 2625314")}
        ></View>
        <View
          width="470px"
          height="22px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="270.21px"
          left="152.41px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(243,243,243,1)"
          {...getOverrideProps(overrides, "Rectangle 27")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="600"
          color="rgba(0,0,0,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="440px"
          height="57px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="284.91px"
          left="209.49px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="$1000"
          {...getOverrideProps(overrides, "$1000")}
        ></Text>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="600"
          color="rgba(0,0,0,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="440px"
          height="57px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="285.11px"
          left="170.49px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="$250"
          {...getOverrideProps(overrides, "$250")}
        ></Text>
        <View
          width="470px"
          height="22px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="270.42px"
          left="112.41px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(243,243,243,1)"
          {...getOverrideProps(overrides, "Rectangle 28")}
        ></View>
        <View
          width="470px"
          height="22px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="270.62px"
          left="73.41px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(243,243,243,1)"
          {...getOverrideProps(overrides, "Rectangle 29")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="600"
          color="rgba(0,0,0,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="unset"
          height="unset"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="285.42px"
          left="111.49px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="$500"
          {...getOverrideProps(overrides, "$500")}
        ></Text>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="600"
          color="rgba(0,0,0,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="440px"
          height="57px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="285.52px"
          left="91.49px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="$450"
          {...getOverrideProps(overrides, "$450")}
        ></Text>
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="797.81px"
          left="421.18px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 13")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="117.25px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button58532")}
          >
            <View
              width="116.77px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(88,204,2,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(88,204,2,1)"
              {...getOverrideProps(overrides, "Rectangle58533")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="104.25px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="6px"
              left="13px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="RETURN TO HOMEPAGE"
              {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
            ></Text>
          </View>
        </View>
      </View>
      <Image
        width="10.88%"
        height="66.07%"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="30.73%"
        bottom="3.2%"
        left="0.86%"
        right="88.26%"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(overrides, "Character_5_Standing")}
      ></Image>
    </View>
  );
}
