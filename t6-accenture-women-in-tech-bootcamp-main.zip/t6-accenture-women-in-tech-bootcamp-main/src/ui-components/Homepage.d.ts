/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type HomepageOverridesProps = {
    Homepage?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 6"?: PrimitiveOverrideProps<ViewProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button58566?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58567?: PrimitiveOverrideProps<ViewProps>;
    "START FIRST LESSON"?: PrimitiveOverrideProps<TextProps>;
    Button58569?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58570?: PrimitiveOverrideProps<ViewProps>;
    "VIEW ALL LESSONS"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    "Group 12"?: PrimitiveOverrideProps<ViewProps>;
    Button58579?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58580?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 26"?: PrimitiveOverrideProps<ViewProps>;
    "Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided"?: PrimitiveOverrideProps<TextProps>;
    Character_4_Standing?: PrimitiveOverrideProps<ImageProps>;
    "Professional Financial Investment Company and Success Symbol Logo 2"?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type HomepageProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: HomepageOverridesProps | undefined | null;
}>;
export default function Homepage(props: HomepageProps): React.ReactElement;
