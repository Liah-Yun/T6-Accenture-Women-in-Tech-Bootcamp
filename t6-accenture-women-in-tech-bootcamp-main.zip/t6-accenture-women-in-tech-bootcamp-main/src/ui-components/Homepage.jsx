/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function Homepage(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "Homepage")}
      {...rest}
    >
      <View
        width="720px"
        height="46px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="789.75px"
        left="432.14px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 6")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="360px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="319.59px"
        left="78.67px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 6")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="173.12px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="186.88px"
          {...getOverrideProps(overrides, "Button58566")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(229,229,229,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(255,255,255,1)"
            {...getOverrideProps(overrides, "Rectangle58567")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(28,176,246,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="145px"
            height="12px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="12px"
            left="28.12px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="START FIRST LESSON"
            {...getOverrideProps(overrides, "START FIRST LESSON")}
          ></Text>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button58569")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(109,199,249,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle58570")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="102px"
            height="12px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="12px"
            left="44px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="VIEW ALL LESSONS"
            {...getOverrideProps(overrides, "VIEW ALL LESSONS")}
          ></Text>
        </View>
      </View>
      <View
        width="926px"
        height="32px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="-0.24px"
        left="428px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 27")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="61.17px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="7.8px"
        left="421.04px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 12")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button58579")}
        >
          <View
            width="50.6px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(206,72,42,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(206,72,42,1)"
            {...getOverrideProps(overrides, "Rectangle58580")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="45.17px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="4.47px"
            left="16px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="EXIT"
            {...getOverrideProps(overrides, "EXIT")}
          ></Text>
        </View>
      </View>
      <View
        width="500px"
        height="183px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="243.28px"
        left="329.27px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 26")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="500"
        color="rgba(0,0,0,1)"
        textTransform="capitalize"
        lineHeight="25px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="390.69px"
        height="112.87px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="303.47px"
        left="293.59px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided  "
        {...getOverrideProps(
          overrides,
          "Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided"
        )}
      ></Text>
      <Image
        width="93px"
        height="281px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="22.47px"
        left="292.12px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(overrides, "Character_4_Standing")}
      ></Image>
      <Image
        width="54px"
        height="136px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="126.21px"
        left="151.66px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(
          overrides,
          "Professional Financial Investment Company and Success Symbol Logo 2"
        )}
      ></Image>
    </View>
  );
}
