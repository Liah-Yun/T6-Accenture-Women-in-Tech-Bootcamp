/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz04OverridesProps = {
    Quiz04?: PrimitiveOverrideProps<ViewProps>;
    "Quiz 4"?: PrimitiveOverrideProps<ViewProps>;
    "Group 9"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625226"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625326"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 21"?: PrimitiveOverrideProps<ViewProps>;
    "Can you still be entitled for Super if you are under 18 years old?"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25333?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25334?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 6"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 7"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 8"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 9"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 2625341"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 2625342"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 28"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 29"?: PrimitiveOverrideProps<ViewProps>;
    Yes?: PrimitiveOverrideProps<TextProps>;
    No?: PrimitiveOverrideProps<TextProps>;
    "Yes, under certain circumstances"?: PrimitiveOverrideProps<TextProps>;
    Unsure?: PrimitiveOverrideProps<TextProps>;
    "Group 10"?: PrimitiveOverrideProps<ViewProps>;
    Button25504?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25505?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 14"?: PrimitiveOverrideProps<ViewProps>;
    Button58536?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58537?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    Character_4_Standing?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type Quiz04Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz04OverridesProps | undefined | null;
}>;
export default function Quiz04(props: Quiz04Props): React.ReactElement;
