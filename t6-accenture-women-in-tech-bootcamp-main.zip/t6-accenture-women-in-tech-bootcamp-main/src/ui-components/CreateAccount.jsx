/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function CreateAccount(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "CreateAccount")}
      {...rest}
    >
      <Text
        fontFamily="Inter"
        fontSize="24px"
        fontWeight="700"
        color="rgba(43,175,231,1)"
        lineHeight="29.045454025268555px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="252px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="83px"
        left="calc(50% - 126px - 0px)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="CREATE ACCOUNT"
        {...getOverrideProps(overrides, "CREATE ACCOUNT")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="145px"
        left="76px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 2")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="145px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Name"
        {...getOverrideProps(overrides, "Name")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="224px"
        left="76px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 3")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="224px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Username"
        {...getOverrideProps(overrides, "Username")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="303px"
        left="76px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 4")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="303px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="E-mail"
        {...getOverrideProps(overrides, "E-mail")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="388px"
        left="76px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 5")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="388px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Password"
        {...getOverrideProps(overrides, "Password")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="467px"
        left="76px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 6")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="467px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Retype Password"
        {...getOverrideProps(overrides, "Retype Password")}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="306.23px"
        height="53px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="635px"
        left="61px"
        {...getOverrideProps(overrides, "Group 7")}
      >
        <View
          width="306.23px"
          height="53px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          border="2px SOLID rgba(109,199,249,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="20px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="149.74px"
          height="unset"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="18px"
          left="78px"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="next"
          {...getOverrideProps(overrides, "next")}
        ></Text>
      </View>
      <Image
        width="29px"
        height="69px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="800px"
        left="203px"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(
          overrides,
          "Professional Financial Investment Company and Success Symbol Logo 1"
        )}
      ></Image>
    </View>
  );
}
