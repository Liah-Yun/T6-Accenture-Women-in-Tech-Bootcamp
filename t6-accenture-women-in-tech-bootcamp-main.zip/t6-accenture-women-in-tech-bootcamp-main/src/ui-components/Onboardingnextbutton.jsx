/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function Onboardingnextbutton(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="306.23px"
      height="53px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Onboardingnextbutton")}
      {...rest}
    >
      <View
        width="306.23px"
        height="53px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0%"
        border="2px SOLID rgba(109,199,249,1)"
        boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
        borderRadius="12px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="700"
        color="rgba(255,255,255,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="149.74px"
        height="unset"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="33.96%"
        bottom="32.08%"
        left="25.47%"
        right="25.63%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="next"
        {...getOverrideProps(overrides, "next")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="-1105.66%"
        bottom="1143.4%"
        left="-309.24%"
        right="323.03%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Name"
        {...getOverrideProps(overrides, "Name")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="-956.6%"
        bottom="994.34%"
        left="-309.24%"
        right="323.03%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Username"
        {...getOverrideProps(overrides, "Username")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="-647.17%"
        bottom="684.91%"
        left="-309.24%"
        right="323.03%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Password"
        {...getOverrideProps(overrides, "Password")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="-498.11%"
        bottom="535.85%"
        left="-309.24%"
        right="323.03%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Retype Password"
        {...getOverrideProps(overrides, "Retype Password")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="20px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="24.204544067382812px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="-807.55%"
        bottom="845.28%"
        left="-309.24%"
        right="323.03%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="E-mail"
        {...getOverrideProps(overrides, "E-mail")}
      ></Text>
    </View>
  );
}
