/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function TrueOrFalse(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="234.71px"
      height="520.63px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "TrueOrFalse")}
      {...rest}
    >
      <View
        width="520px"
        height="121px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="76.76%"
        left="98.84%"
        right="-220.39%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 2125199")}
      ></View>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0.55%"
        bottom="86.58%"
        left="28.55%"
        right="-22.7%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 2125201")}
      ></View>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="57.02%"
        bottom="30.11%"
        left="29.2%"
        right="-23.36%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 22")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="13px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="488px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="16.13px"
        left="207.07px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
        {...getOverrideProps(
          overrides,
          "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
        )}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="128px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="9.59%"
        bottom="82.34%"
        left="23.54%"
        right="21.93%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="TRUE"
        {...getOverrideProps(overrides, "TRUE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="122px"
        height="38px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="66.63%"
        bottom="26.07%"
        left="25.05%"
        right="22.97%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="FALSE"
        {...getOverrideProps(overrides, "FALSE")}
      ></Text>
    </View>
  );
}
