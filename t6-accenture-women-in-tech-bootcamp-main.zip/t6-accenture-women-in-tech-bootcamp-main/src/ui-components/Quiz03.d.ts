/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz03OverridesProps = {
    Quiz03?: PrimitiveOverrideProps<ViewProps>;
    "Quiz 3"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 2625312"?: PrimitiveOverrideProps<ViewProps>;
    "Group 8"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625223"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625297"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 21"?: PrimitiveOverrideProps<ViewProps>;
    "How much do you have to earn per month before tax to be entitled for Super?"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25304?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25305?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    "Group 9"?: PrimitiveOverrideProps<ViewProps>;
    Button25491?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25492?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 6"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 7"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 8"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 9"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 2625314"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    $1000?: PrimitiveOverrideProps<TextProps>;
    $250?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 28"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 29"?: PrimitiveOverrideProps<ViewProps>;
    $500?: PrimitiveOverrideProps<TextProps>;
    $450?: PrimitiveOverrideProps<TextProps>;
    "Group 13"?: PrimitiveOverrideProps<ViewProps>;
    Button58532?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58533?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    Character_5_Standing?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type Quiz03Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz03OverridesProps | undefined | null;
}>;
export default function Quiz03(props: Quiz03Props): React.ReactElement;
