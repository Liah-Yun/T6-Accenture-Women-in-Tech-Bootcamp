/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type AIChatbotOverridesProps = {
    AIChatbot?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 6"?: PrimitiveOverrideProps<ViewProps>;
    "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25478?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25479?: PrimitiveOverrideProps<ViewProps>;
    "Continue to next lesson"?: PrimitiveOverrideProps<TextProps>;
    Button25481?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25482?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 28"?: PrimitiveOverrideProps<ViewProps>;
    "Group 15"?: PrimitiveOverrideProps<ViewProps>;
    Button58556?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58557?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 30"?: PrimitiveOverrideProps<ViewProps>;
    "Type your question..."?: PrimitiveOverrideProps<TextProps>;
    "Group 8"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 858609"?: PrimitiveOverrideProps<IconProps>;
    "Polygon 158610"?: PrimitiveOverrideProps<IconProps>;
    "I\u2019m just about to get my first job, what should I know about Super?"?: PrimitiveOverrideProps<TextProps>;
    "Group 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 858602"?: PrimitiveOverrideProps<IconProps>;
    "Polygon 158603"?: PrimitiveOverrideProps<IconProps>;
    "Hi, I\u2019m your SuperSavvy AI Assist, Please type in any question you have about superannuation :)"?: PrimitiveOverrideProps<TextProps>;
    "Professional Financial Investment Company and Success Symbol Logo 3"?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type AIChatbotProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: AIChatbotOverridesProps | undefined | null;
}>;
export default function AIChatbot(props: AIChatbotProps): React.ReactElement;
