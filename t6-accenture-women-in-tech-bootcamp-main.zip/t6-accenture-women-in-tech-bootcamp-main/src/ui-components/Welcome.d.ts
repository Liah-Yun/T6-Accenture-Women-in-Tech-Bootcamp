/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type WelcomeOverridesProps = {
    Welcome?: PrimitiveOverrideProps<ViewProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button58566?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58567?: PrimitiveOverrideProps<ViewProps>;
    "START FIRST LESSON"?: PrimitiveOverrideProps<TextProps>;
    Button58569?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58570?: PrimitiveOverrideProps<ViewProps>;
    "VIEW ALL LESSONS"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 26"?: PrimitiveOverrideProps<ViewProps>;
    "Welcome to SuperSavvy, where you unlock your finanical future. Start your learnings by clicking start first lesson or you can also view all lessons provided"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type WelcomeProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: WelcomeOverridesProps | undefined | null;
}>;
export default function Welcome(props: WelcomeProps): React.ReactElement;
