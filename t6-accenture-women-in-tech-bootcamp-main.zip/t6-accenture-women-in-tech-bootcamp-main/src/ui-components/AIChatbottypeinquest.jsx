/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function AIChatbottypeinquest(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="356px"
      height="82px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "AIChatbottypeinquest")}
      {...rest}
    >
      <View
        width="356px"
        height="82px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 30")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="15px"
        fontWeight="700"
        color="rgba(255,255,255,1)"
        textTransform="capitalize"
        lineHeight="25px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="286px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="29.27%"
        bottom="30.49%"
        left="9.83%"
        right="9.83%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Type your question..."
        {...getOverrideProps(overrides, "Type your question...")}
      ></Text>
    </View>
  );
}
