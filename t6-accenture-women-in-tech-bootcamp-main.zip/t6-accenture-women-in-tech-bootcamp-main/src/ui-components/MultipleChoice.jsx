/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Text, View } from "@aws-amplify/ui-react";
export default function MultipleChoice(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="293.39px"
      height="520.63px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "MultipleChoice")}
      {...rest}
    >
      <View
        width="520px"
        height="121px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="76.76%"
        left="99.07%"
        right="-176.31%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 21")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="13px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="488px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="3.11%"
        bottom="60.2%"
        left="85.13%"
        right="-151.46%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is the minimum age to be entitled for Super?"
        {...getOverrideProps(
          overrides,
          "What is the minimum age to be entitled for Super?"
        )}
      ></Text>
      <Icon
        width="19px"
        height="19px"
        viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
        paths={[
          {
            d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
            fill: "rgba(217,217,217,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0.14%"
        bottom="96.21%"
        left="52.38%"
        right="41.15%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Ellipse 6")}
      ></Icon>
      <Icon
        width="19px"
        height="19px"
        viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
        paths={[
          {
            d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
            fill: "rgba(217,217,217,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0.18%"
        bottom="96.17%"
        left="38.74%"
        right="54.78%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Ellipse 7")}
      ></Icon>
      <Icon
        width="19px"
        height="19px"
        viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
        paths={[
          {
            d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
            fill: "rgba(217,217,217,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0.22%"
        bottom="96.13%"
        left="25.11%"
        right="68.41%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Ellipse 8")}
      ></Icon>
      <Icon
        width="19px"
        height="19px"
        viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
        paths={[
          {
            d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
            fill: "rgba(217,217,217,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0.26%"
        bottom="96.09%"
        left="12.16%"
        right="81.36%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Ellipse 9")}
      ></Icon>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="9.16%"
        bottom="86.61%"
        left="53.48%"
        right="-113.68%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 22")}
      ></View>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="9.2%"
        bottom="86.57%"
        left="40.19%"
        right="-100.39%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 23")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="12.03%"
        bottom="77.03%"
        left="59.65%"
        right="-109.61%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="16"
        {...getOverrideProps(overrides, "16")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="12.06%"
        bottom="76.99%"
        left="46.35%"
        right="-96.32%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="21"
        {...getOverrideProps(overrides, "21")}
      ></Text>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="9.24%"
        bottom="86.53%"
        left="26.56%"
        right="-86.75%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 24")}
      ></View>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="9.28%"
        bottom="86.49%"
        left="13.27%"
        right="-73.46%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 25")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="unset"
        height="unset"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="12.12%"
        bottom="84.42%"
        left="26.24%"
        right="68.64%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="18"
        {...getOverrideProps(overrides, "18")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="12.14%"
        bottom="76.91%"
        left="19.43%"
        right="-69.4%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="30"
        {...getOverrideProps(overrides, "30")}
      ></Text>
    </View>
  );
}
