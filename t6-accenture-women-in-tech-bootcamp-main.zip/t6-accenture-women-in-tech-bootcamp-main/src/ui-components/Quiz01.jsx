/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function Quiz01(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="928.23px"
      height="432.84px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Quiz01")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="98.88%"
        bottom="-212.81%"
        left="0%"
        right="53.89%"
        transformOrigin="top left"
        transform="rotate(-89.7deg)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Quiz 1")}
      >
        <View
          width="926px"
          height="32px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="-0.26px"
          left="431px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 27")}
        ></View>
        <View
          width="520px"
          height="121px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="234.3px"
          left="325.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 2125199")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="13px"
          fontWeight="600"
          color="rgba(255,255,255,1)"
          lineHeight="30px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0px"
          width="488px"
          height="191px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="250.43px"
          left="300.31px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
          {...getOverrideProps(
            overrides,
            "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"
          )}
        ></Text>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="755.75px"
          left="49.95px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 6")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25207")}
          >
            <View
              width="156.4px"
              height="34.61px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(109,199,249,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(43,175,231,1)"
              {...getOverrideProps(overrides, "Rectangle25208")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="18px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              letterSpacing="0.65px"
              width="67.85px"
              height="11.75px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="11.75px"
              left="44.28px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="Next Question "
              {...getOverrideProps(overrides, "Next Question")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="191.08px"
          left="368px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 1")}
        >
          <View
            width="587px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(240,240,240,1)"
            {...getOverrideProps(overrides, "Rectangle 6")}
          ></View>
          <View
            width="107.41px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle 7")}
          ></View>
        </View>
        <Icon
          width="34px"
          height="35px"
          viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
          paths={[
            {
              d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
              fill: "rgba(252,197,26,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="764px"
          left="384px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Star 1")}
        ></Icon>
        <Image
          width="121px"
          height="322px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="14.24px"
          left="337.07px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          {...getOverrideProps(overrides, "Character_1_Standing")}
        ></Image>
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="5.8px"
          left="421.03px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 10")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="61.17px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25499")}
          >
            <View
              width="50.6px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(206,72,42,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(206,72,42,1)"
              {...getOverrideProps(overrides, "Rectangle25500")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="45.17px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="4.47px"
              left="16px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="EXIT"
              {...getOverrideProps(overrides, "EXIT")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="797.79px"
          left="424.18px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 11")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="117.25px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25524")}
          >
            <View
              width="116.77px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(88,204,2,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(88,204,2,1)"
              {...getOverrideProps(overrides, "Rectangle25525")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="104.25px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="6px"
              left="13px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="RETURN TO HOMEPAGE"
              {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
            ></Text>
          </View>
        </View>
      </View>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="62.15%"
        bottom="22.37%"
        left="25.64%"
        right="50.55%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 2125201")}
      ></View>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="62.15%"
        bottom="22.37%"
        left="57.31%"
        right="18.88%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 22")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="128px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="64.92%"
        bottom="25.38%"
        left="30.7%"
        right="55.51%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="TRUE"
        {...getOverrideProps(overrides, "TRUE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="122px"
        height="38px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="64.46%"
        bottom="26.76%"
        left="62.7%"
        right="24.16%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="FALSE"
        {...getOverrideProps(overrides, "FALSE")}
      ></Text>
    </View>
  );
}
