/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type MultipleChoiceOverridesProps = {
    "16"?: PrimitiveOverrideProps<TextProps>;
    "18"?: PrimitiveOverrideProps<TextProps>;
    "21"?: PrimitiveOverrideProps<TextProps>;
    "30"?: PrimitiveOverrideProps<TextProps>;
    MultipleChoice?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 21"?: PrimitiveOverrideProps<ViewProps>;
    "What is the minimum age to be entitled for Super?"?: PrimitiveOverrideProps<TextProps>;
    "Ellipse 6"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 7"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 8"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 9"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 22"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 23"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 24"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 25"?: PrimitiveOverrideProps<ViewProps>;
} & EscapeHatchProps;
export declare type MultipleChoiceProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: MultipleChoiceOverridesProps | undefined | null;
}>;
export default function MultipleChoice(props: MultipleChoiceProps): React.ReactElement;
