/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Text, View } from "@aws-amplify/ui-react";
export default function Lessons(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="297.53px"
      height="587.08px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Lessons")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="97.1%"
        left="81.25%"
        right="-178.54%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 1")}
      >
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(240,240,240,1)"
          {...getOverrideProps(overrides, "Rectangle 6")}
        ></View>
        <View
          width="107.41px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="81.7%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 7")}
        ></View>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="467px"
        height="193px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="8.22%"
        bottom="58.91%"
        left="64.87%"
        right="-121.83%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 3")}
      >
        <Icon
          width="415.67px"
          height="193px"
          viewBox={{ minX: 0, minY: 0, width: 415.67431640625, height: 193 }}
          paths={[
            {
              d: "M1.11672e-14 39.9954C8.27869e-15 17.9041 17.9086 0 40 0L375.674 0C397.766 0 415.674 17.9086 415.674 40L415.674 153C415.674 175.091 397.766 193 375.674 193L40 193C17.9086 193 -1.52616e-14 175.124 -1.0742e-14 153.033C-8.93763e-15 144.213 -5.57729e-15 133.478 0 120.419C1.31078e-14 89.7267 1.39703e-14 61.4339 1.11672e-14 39.9954Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="10.99%"
          right="0%"
          {...getOverrideProps(overrides, "Rectangle 8")}
        ></Icon>
        <Icon
          width="52.86px"
          height="62.48px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 62.998046875,
            height: 53.626708984375,
          }}
          paths={[
            {
              d: "M26.2526 4.16178C27.8964 27.3844 31.8218 40.25 52.8565 62.476L0 62.476C0 62.476 24.6089 -19.0609 26.2526 4.16178Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="64.2%"
          bottom="3.43%"
          left="0.11%"
          right="88.57%"
          transformOrigin="top left"
          transform="rotate(-90.57deg)"
          {...getOverrideProps(overrides, "Polygon 1")}
        ></Icon>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="500"
          color="rgba(0,0,0,1)"
          textTransform="capitalize"
          lineHeight="25px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="390.69px"
          height="112.87px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="21.24%"
          bottom="20.28%"
          left="13.7%"
          right="2.64%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="“Building your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow?”"
          {...getOverrideProps(
            overrides,
            "\u201CBuilding your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow?\u201D"
          )}
        ></Text>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="450px"
        height="62px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="13.92%"
        bottom="75.52%"
        left="99.21%"
        right="-150.45%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 2")}
      >
        <Text
          fontFamily="Inter"
          fontSize="25px"
          fontWeight="600"
          color="rgba(43,175,231,1)"
          textTransform="capitalize"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="450px"
          height="62px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Lesson 1 : What is Superannuation"
          {...getOverrideProps(overrides, "Lesson 1 : What is Superannuation")}
        ></Text>
      </View>
    </View>
  );
}
