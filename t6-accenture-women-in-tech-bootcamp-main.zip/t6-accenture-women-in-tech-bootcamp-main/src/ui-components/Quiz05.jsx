/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function Quiz05(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "Quiz05")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="194.05px"
        left="372.02px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 10")}
      >
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(240,240,240,1)"
          {...getOverrideProps(overrides, "Rectangle 625379")}
        ></View>
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 7")}
        ></View>
      </View>
      <View
        width="720px"
        height="46px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="789.75px"
        left="432.14px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 625357")}
      ></View>
      <View
        width="520px"
        height="121px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="234.3px"
        left="325.23px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 21")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="13px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="488px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="250.43px"
        left="300.31px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Superannuation guarantee is a government program that guarantees a minimum annual return on your investments in the stock market "
        {...getOverrideProps(
          overrides,
          "Superannuation guarantee is a government program that guarantees a minimum annual return on your investments in the stock market"
        )}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="156.4px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="755.77px"
        left="45.95px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 6")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button25364")}
        >
          <View
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(109,199,249,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle25365")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="18px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="67.85px"
            height="11.75px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="11.75px"
            left="44.28px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="Next Question "
            {...getOverrideProps(overrides, "Next Question")}
          ></Text>
        </View>
      </View>
      <Image
        width="121px"
        height="322px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="14.24px"
        left="337.07px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(overrides, "Character_1_Standing")}
      ></Image>
      <Icon
        width="34px"
        height="35px"
        viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
        paths={[
          {
            d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
            fill: "rgba(252,197,26,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="764px"
        left="384px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Star 1")}
      ></Icon>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="240.11px"
        left="170.25px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 26")}
      ></View>
      <View
        width="221px"
        height="67px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="534.11px"
        left="171.79px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 27")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="128px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="287.18px"
        left="157.5px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="TRUE"
        {...getOverrideProps(overrides, "TRUE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="14px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        lineHeight="45px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="122px"
        height="38px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="584.17px"
        left="160.06px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="FALSE"
        {...getOverrideProps(overrides, "FALSE")}
      ></Text>
      <View
        width="926px"
        height="32px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="-0.24px"
        left="428px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 30")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="61.17px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="5.8px"
        left="421.03px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 11")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button25508")}
        >
          <View
            width="50.6px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(206,72,42,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(206,72,42,1)"
            {...getOverrideProps(overrides, "Rectangle25509")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="45.17px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="4.47px"
            left="16px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="EXIT"
            {...getOverrideProps(overrides, "EXIT")}
          ></Text>
        </View>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="117.25px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="797.81px"
        left="421.18px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 15")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button58540")}
        >
          <View
            width="116.77px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(88,204,2,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(88,204,2,1)"
            {...getOverrideProps(overrides, "Rectangle58541")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="104.25px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="6px"
            left="13px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="RETURN TO HOMEPAGE"
            {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
          ></Text>
        </View>
      </View>
    </View>
  );
}
