/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type NextLevelOverridesProps = {
    NextLevel?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625438"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 8"?: PrimitiveOverrideProps<ViewProps>;
    "Congratulations! You have unlocked a new level"?: PrimitiveOverrideProps<TextProps>;
    "GO TO NEW\u2028LEVEL"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 2625445"?: PrimitiveOverrideProps<ViewProps>;
    "Group 1"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625465"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Group 4"?: PrimitiveOverrideProps<ViewProps>;
    "Lesson 1 : What is Superannuation"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 2625470"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 29"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 28"?: PrimitiveOverrideProps<ViewProps>;
    "BACK TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    "TAKE ME TO ATO WEBSITE"?: PrimitiveOverrideProps<TextProps>;
    "RETAKE QUIZ"?: PrimitiveOverrideProps<TextProps>;
    "Group 13"?: PrimitiveOverrideProps<ViewProps>;
    Button25520?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25521?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 14"?: PrimitiveOverrideProps<ViewProps>;
    Button58552?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58553?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    Character_5_Standing?: PrimitiveOverrideProps<ImageProps>;
    "Professional Financial Investment Company and Success Symbol Logo 2"?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type NextLevelProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: NextLevelOverridesProps | undefined | null;
}>;
export default function NextLevel(props: NextLevelProps): React.ReactElement;
