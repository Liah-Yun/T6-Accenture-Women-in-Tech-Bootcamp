/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function Quiz02(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="928.23px"
      height="432.84px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Quiz02")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="98.88%"
        bottom="-212.81%"
        left="0%"
        right="53.89%"
        transformOrigin="top left"
        transform="rotate(-89.7deg)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Quiz 2")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="194.05px"
          left="372.02px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 7")}
        >
          <View
            width="587px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(240,240,240,1)"
            {...getOverrideProps(overrides, "Rectangle 625217")}
          ></View>
          <View
            width="197px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle 7")}
          ></View>
        </View>
        <View
          width="720px"
          height="46px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="789.75px"
          left="432.14px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 625252")}
        ></View>
        <View
          width="520px"
          height="121px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="234.3px"
          left="325.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 21")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="13px"
          fontWeight="600"
          color="rgba(255,255,255,1)"
          lineHeight="30px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0px"
          width="488px"
          height="191px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="250.51px"
          left="284.31px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="What is the minimum age to be entitled for Super?"
          {...getOverrideProps(
            overrides,
            "What is the minimum age to be entitled for Super?"
          )}
        ></Text>
        <View
          padding="0px 0px 0px 0px"
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="755.75px"
          left="48.95px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 6")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25260")}
          >
            <View
              width="156.4px"
              height="34.61px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(109,199,249,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(43,175,231,1)"
              {...getOverrideProps(overrides, "Rectangle25261")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="18px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              letterSpacing="0.65px"
              width="67.85px"
              height="11.75px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="11.75px"
              left="44.28px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="Next Question "
              {...getOverrideProps(overrides, "Next Question")}
            ></Text>
          </View>
        </View>
        <Icon
          width="34px"
          height="35px"
          viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
          paths={[
            {
              d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
              fill: "rgba(252,197,26,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="764px"
          left="384px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Star 1")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.02px"
          left="188.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 6")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.23px"
          left="148.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 7")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.44px"
          left="108.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 8")}
        ></Icon>
        <Icon
          width="19px"
          height="19px"
          viewBox={{ minX: 0, minY: 0, width: 19, height: 19 }}
          paths={[
            {
              d: "M19 9.5C19 14.7467 14.7467 19 9.5 19C4.25329 19 0 14.7467 0 9.5C0 4.25329 4.25329 0 9.5 0C14.7467 0 19 4.25329 19 9.5Z",
              fill: "rgba(217,217,217,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235.64px"
          left="70.23px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Ellipse 9")}
        ></Icon>
        <View
          width="926px"
          height="32px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="-0.24px"
          left="428px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 26")}
        ></View>
        <Image
          width="374px"
          height="310px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="138.42px"
          left="302.72px"
          transformOrigin="top left"
          transform="rotate(-90.3deg)"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          {...getOverrideProps(overrides, "he_sitting_with_notebook 3")}
        ></Image>
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="7.8px"
          left="421.04px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 10")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="61.17px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25495")}
          >
            <View
              width="50.6px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(206,72,42,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(206,72,42,1)"
              {...getOverrideProps(overrides, "Rectangle25496")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="45.17px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="4.47px"
              left="16px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="EXIT"
              {...getOverrideProps(overrides, "EXIT")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="797.81px"
          left="421.18px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 12")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="117.25px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button58528")}
          >
            <View
              width="116.77px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(88,204,2,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(88,204,2,1)"
              {...getOverrideProps(overrides, "Rectangle58529")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="104.25px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="6px"
              left="13px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="RETURN TO HOMEPAGE"
              {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
            ></Text>
          </View>
        </View>
      </View>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="54.99%"
        bottom="39.93%"
        left="30.49%"
        right="18.88%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 22")}
      ></View>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="64%"
        bottom="30.92%"
        left="30.49%"
        right="18.88%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 23")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="50.83%"
        bottom="36%"
        left="32.1%"
        right="20.49%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="16"
        {...getOverrideProps(overrides, "16")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="59.84%"
        bottom="26.99%"
        left="32.1%"
        right="20.49%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="21"
        {...getOverrideProps(overrides, "21")}
      ></Text>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="73.24%"
        bottom="21.68%"
        left="30.49%"
        right="18.88%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 24")}
      ></View>
      <View
        width="470px"
        height="22px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="82.25%"
        bottom="12.67%"
        left="30.49%"
        right="18.88%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 25")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="unset"
        height="unset"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="73.47%"
        bottom="22.37%"
        left="32.1%"
        right="66.28%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="18"
        {...getOverrideProps(overrides, "18")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(0,0,0,1)"
        textTransform="uppercase"
        lineHeight="18px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0.65px"
        width="440px"
        height="57px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="78.09%"
        bottom="8.74%"
        left="32.1%"
        right="20.49%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="30"
        {...getOverrideProps(overrides, "30")}
      ></Text>
    </View>
  );
}
