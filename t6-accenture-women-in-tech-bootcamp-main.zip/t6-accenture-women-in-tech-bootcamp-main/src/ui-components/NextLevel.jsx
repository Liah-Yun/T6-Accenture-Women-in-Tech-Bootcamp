/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function NextLevel(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "NextLevel")}
      {...rest}
    >
      <View
        width="214px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="577.29px"
        left="138.02px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(88,204,2,1)"
        {...getOverrideProps(overrides, "Rectangle 27")}
      ></View>
      <View
        width="720px"
        height="46px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="789.75px"
        left="432.14px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 625438")}
      ></View>
      <View
        width="397px"
        height="126px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="267.47px"
        left="292.4px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(252,197,26,1)"
        {...getOverrideProps(overrides, "Rectangle 8")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="18px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="286px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="323.61px"
        left="266.69px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Congratulations! You have unlocked a new level "
        {...getOverrideProps(
          overrides,
          "Congratulations! You have unlocked a new level"
        )}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="119px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="624.42px"
        left="113.27px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="GO TO NEW&#x2028;LEVEL"
        {...getOverrideProps(overrides, "GO TO NEW\u2028LEVEL")}
      ></Text>
      <View
        width="926px"
        height="32px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="-0.24px"
        left="428px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 2625445")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="161.23px"
        left="338.84px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 1")}
      >
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(240,240,240,1)"
          {...getOverrideProps(overrides, "Rectangle 625465")}
        ></View>
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 7")}
        ></View>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="484px"
        height="62px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="239.92px"
        left="397.26px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 4")}
      >
        <Text
          fontFamily="Inter"
          fontSize="25px"
          fontWeight="600"
          color="rgba(43,175,231,1)"
          textTransform="capitalize"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="484px"
          height="62px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="0px"
          left="0px"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Lesson 1 : What is Superannuation"
          {...getOverrideProps(overrides, "Lesson 1 : What is Superannuation")}
        ></Text>
      </View>
      <View
        width="128px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="95.29px"
        left="135.49px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 2625470")}
      ></View>
      <View
        width="128px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="241.29px"
        left="136.26px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 29")}
      ></View>
      <View
        width="125px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="387.29px"
        left="137.02px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 28")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(0,0,0,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="105.44px"
        left="107.55px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="BACK TO HOMEPAGE"
        {...getOverrideProps(overrides, "BACK TO HOMEPAGE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(0,0,0,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="252.42px"
        left="111.32px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="TAKE ME TO&#xA; ATO WEBSITE"
        {...getOverrideProps(overrides, "TAKE ME TO ATO WEBSITE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(255,255,255,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="396.43px"
        left="110.07px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="RETAKE &#xA;QUIZ"
        {...getOverrideProps(overrides, "RETAKE QUIZ")}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="61.17px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="9.8px"
        left="421.05px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 13")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button25520")}
        >
          <View
            width="50.6px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(206,72,42,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(206,72,42,1)"
            {...getOverrideProps(overrides, "Rectangle25521")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="45.17px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="4.47px"
            left="16px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="EXIT"
            {...getOverrideProps(overrides, "EXIT")}
          ></Text>
        </View>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="117.25px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="803.81px"
        left="421.21px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 14")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          {...getOverrideProps(overrides, "Button58552")}
        >
          <View
            width="116.77px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="1px SOLID rgba(88,204,2,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(88,204,2,1)"
            {...getOverrideProps(overrides, "Rectangle58553")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="104.25px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="6px"
            left="13px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="RETURN TO HOMEPAGE"
            {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
          ></Text>
        </View>
      </View>
      <Image
        width="101px"
        height="286px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="817.47px"
        left="295.28px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(overrides, "Character_5_Standing")}
      ></Image>
      <Image
        width="29px"
        height="69px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="761.06px"
        left="372.98px"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(
          overrides,
          "Professional Financial Investment Company and Success Symbol Logo 2"
        )}
      ></Image>
    </View>
  );
}
