/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz07OverridesProps = {
    Quiz07?: PrimitiveOverrideProps<ViewProps>;
    "Resource Page"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625411"?: PrimitiveOverrideProps<ViewProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25415?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25416?: PrimitiveOverrideProps<ViewProps>;
    "Continue to NEXT LEARNING"?: PrimitiveOverrideProps<TextProps>;
    Button25418?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25419?: PrimitiveOverrideProps<ViewProps>;
    "PREVIOUS LEARNING"?: PrimitiveOverrideProps<TextProps>;
    "Group 1"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625422"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    Character_4_Standing?: PrimitiveOverrideProps<ImageProps>;
    "Group 12"?: PrimitiveOverrideProps<ViewProps>;
    Button25516?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25517?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 13"?: PrimitiveOverrideProps<ViewProps>;
    Button58548?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58549?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    "Professional Financial Investment Company and Success Symbol Logo 2"?: PrimitiveOverrideProps<ImageProps>;
    "Group 2"?: PrimitiveOverrideProps<ViewProps>;
    "Lesson 1 : What is Superannuation"?: PrimitiveOverrideProps<TextProps>;
    "Group 3"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 8"?: PrimitiveOverrideProps<IconProps>;
    "Polygon 1"?: PrimitiveOverrideProps<IconProps>;
    "\u201CBuilding your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow?\u201D"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type Quiz07Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz07OverridesProps | undefined | null;
}>;
export default function Quiz07(props: Quiz07Props): React.ReactElement;
