/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function AIChatbotnavbar(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="433.17px"
      height="32px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "AIChatbotnavbar")}
      {...rest}
    >
      <View
        width="433px"
        height="32px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0.04%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(237,237,237,1)"
        {...getOverrideProps(overrides, "Rectangle 28")}
      ></View>
      <View
        padding="0px 0px 0px 0px"
        width="61.17px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="21.87%"
        bottom="25%"
        left="85.88%"
        right="0%"
        {...getOverrideProps(overrides, "Group 15")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          {...getOverrideProps(overrides, "Button")}
        >
          <View
            width="50.6px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0%"
            bottom="0%"
            left="0%"
            right="17.29%"
            border="1px SOLID rgba(206,72,42,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(206,72,42,1)"
            {...getOverrideProps(overrides, "Rectangle")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="8px"
            fontWeight="700"
            color="rgba(255,255,255,1)"
            textTransform="uppercase"
            lineHeight="0px"
            textAlign="left"
            display="block"
            direction="column"
            justifyContent="unset"
            width="45.17px"
            height="5.71px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="26.32%"
            bottom="40.1%"
            left="26.15%"
            right="0%"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="EXIT"
            {...getOverrideProps(overrides, "EXIT")}
          ></Text>
        </View>
      </View>
    </View>
  );
}
