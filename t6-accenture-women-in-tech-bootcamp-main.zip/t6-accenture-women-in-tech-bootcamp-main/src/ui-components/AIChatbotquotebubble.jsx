/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Text, View } from "@aws-amplify/ui-react";
export default function AIChatbotquotebubble(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="433px"
      height="232px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "AIChatbotquotebubble")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="433px"
        height="232px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0%"
        {...getOverrideProps(overrides, "Group 7")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="290px"
          height="95px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="59.05%"
          bottom="0%"
          left="100%"
          right="-66.97%"
          transformOrigin="top left"
          transform="rotate(180deg)"
          {...getOverrideProps(overrides, "Group 8")}
        >
          <Icon
            width="258.13px"
            height="95px"
            viewBox={{ minX: 0, minY: 0, width: 258.126953125, height: 95 }}
            paths={[
              {
                d: "M6.81975e-15 39.9935C1.07534e-14 17.9021 17.9086 0 40 0L218.127 0C240.218 0 258.127 17.9086 258.127 40L258.127 55C258.127 77.0914 240.218 95 218.127 95L35.7265 95C15.9953 95 -1.06309e-14 79.0047 0 59.2735L0 59.2735C3.62344e-15 52.5483 5.74003e-15 46.0572 6.81975e-15 39.9935Z",
                fill: "rgba(225,239,247,1)",
                fillRule: "nonzero",
              },
            ]}
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0%"
            bottom="0%"
            left="10.99%"
            right="0%"
            {...getOverrideProps(overrides, "Rectangle 858609")}
          ></Icon>
          <Icon
            width="26.02px"
            height="38.8px"
            viewBox={{
              minX: 0,
              minY: 0,
              width: 39.12060546875,
              height: 26.3966064453125,
            }}
            paths={[
              {
                d: "M12.9226 2.58432C13.7318 17.0048 15.664 24.9939 26.0182 38.7955L0 38.7955C0 38.7955 12.1135 -11.8361 12.9226 2.58432Z",
                fill: "rgba(225,239,247,1)",
                fillRule: "nonzero",
              },
            ]}
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="64.2%"
            bottom="-5.04%"
            left="0.11%"
            right="90.92%"
            transformOrigin="top left"
            transform="rotate(-90.72deg)"
            {...getOverrideProps(overrides, "Polygon 158610")}
          ></Icon>
          <Text
            fontFamily="Inter"
            fontSize="10px"
            fontWeight="500"
            color="rgba(0,0,0,1)"
            textTransform="capitalize"
            lineHeight="25px"
            textAlign="center"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="230.66px"
            height="55.84px"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="21.05%"
            bottom="20.16%"
            left="95.17%"
            right="-74.71%"
            transformOrigin="top left"
            transform="rotate(180deg)"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="I’m just about to get my first job, what should I know about Super?"
            {...getOverrideProps(
              overrides,
              "I\u2019m just about to get my first job, what should I know about Super?"
            )}
          ></Text>
        </View>
        <Icon
          width="303.52px"
          height="117px"
          viewBox={{ minX: 0, minY: 0, width: 303.52197265625, height: 117 }}
          paths={[
            {
              d: "M9.02186e-15 39.9894C1.00627e-14 17.898 17.9086 0 40 0L263.522 0C285.614 0 303.522 17.9086 303.522 40L303.522 77C303.522 99.0914 285.614 117 263.522 117L40 117C17.9086 117 -1.24537e-14 99.1011 -1.98313e-15 77.0097C-1.36949e-15 75.715 -7.09299e-16 74.3789 0 73C6.0812e-15 61.1784 8.55287e-15 49.9439 9.02186e-15 39.9894Z",
              fill: "rgba(243,243,243,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="49.57%"
          left="8.66%"
          right="21.25%"
          {...getOverrideProps(overrides, "Rectangle 858602")}
        ></Icon>
        <Icon
          width="32.04px"
          height="45.62px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 46.0009765625,
            height: 32.509521484375,
          }}
          paths={[
            {
              d: "M15.9151 3.03883C16.9116 19.9954 19.2914 29.3895 32.0433 45.6184L0 45.6184C0 45.6184 14.9187 -13.9178 15.9151 3.03883Z",
              fill: "rgba(243,243,243,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="32.38%"
          bottom="47.96%"
          left="0.09%"
          right="92.51%"
          transformOrigin="top left"
          transform="rotate(-90.69deg)"
          {...getOverrideProps(overrides, "Polygon 158603")}
        ></Icon>
        <Text
          fontFamily="Inter"
          fontSize="11px"
          fontWeight="500"
          color="rgba(0,0,0,1)"
          textTransform="capitalize"
          lineHeight="25px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="255.32px"
          height="68.78px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="10.22%"
          bottom="60.13%"
          left="14.19%"
          right="26.84%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Hi, I’m your SuperSavvy AI Assist, Please type in any question you have about superannuation :) "
          {...getOverrideProps(
            overrides,
            "Hi, I\u2019m your SuperSavvy AI Assist, Please type in any question you have about superannuation :)"
          )}
        ></Text>
      </View>
    </View>
  );
}
