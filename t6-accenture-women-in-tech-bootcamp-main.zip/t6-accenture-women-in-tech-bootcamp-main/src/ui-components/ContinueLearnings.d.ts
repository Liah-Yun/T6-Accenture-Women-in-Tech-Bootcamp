/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type ContinueLearningsOverridesProps = {
    ContinueLearnings?: PrimitiveOverrideProps<ViewProps>;
    Button25415?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25416?: PrimitiveOverrideProps<ViewProps>;
    "Continue to NEXT LEARNING"?: PrimitiveOverrideProps<TextProps>;
    Button25418?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25419?: PrimitiveOverrideProps<ViewProps>;
    "PREVIOUS LEARNING"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type ContinueLearningsProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: ContinueLearningsOverridesProps | undefined | null;
}>;
export default function ContinueLearnings(props: ContinueLearningsProps): React.ReactElement;
