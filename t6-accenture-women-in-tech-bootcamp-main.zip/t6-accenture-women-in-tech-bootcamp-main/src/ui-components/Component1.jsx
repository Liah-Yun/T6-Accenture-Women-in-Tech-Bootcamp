/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function Component1(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Component1")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Log In Page")}
      >
        <View
          padding="0px 0px 0px 0px"
          width="306.23px"
          height="53px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="723px"
          left="61px"
          {...getOverrideProps(overrides, "Button")}
        >
          <View
            width="306.23px"
            height="53px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            border="2px SOLID rgba(229,229,229,1)"
            boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
            borderRadius="12px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(255,255,255,1)"
            {...getOverrideProps(overrides, "Rectangle414")}
          ></View>
          <Text
            fontFamily="Inter"
            fontSize="20px"
            fontWeight="700"
            color="rgba(28,176,246,1)"
            textTransform="uppercase"
            lineHeight="18px"
            textAlign="center"
            display="block"
            direction="column"
            justifyContent="unset"
            letterSpacing="0.65px"
            width="227.42px"
            height="unset"
            gap="unset"
            alignItems="unset"
            position="absolute"
            top="18px"
            left="39.41px"
            padding="0px 0px 0px 0px"
            whiteSpace="pre-wrap"
            children="REGISTER"
            {...getOverrideProps(overrides, "REGISTER")}
          ></Text>
        </View>
        <Image
          width="327px"
          height="296px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="235px"
          left="50px"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          {...getOverrideProps(
            overrides,
            "Professional Financial Investment Company and Success Symbol Logo (1) 1"
          )}
        ></Image>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="306.23px"
        height="53px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="70.73%"
        bottom="23.54%"
        left="14.25%"
        right="14.2%"
        {...getOverrideProps(overrides, "Group 6")}
      >
        <View
          width="306.23px"
          height="53px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          border="2px SOLID rgba(109,199,249,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle4140")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="20px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="149.74px"
          height="unset"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="33.96%"
          bottom="32.08%"
          left="25.47%"
          right="25.63%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="sign in"
          {...getOverrideProps(overrides, "sign in")}
        ></Text>
      </View>
    </View>
  );
}
