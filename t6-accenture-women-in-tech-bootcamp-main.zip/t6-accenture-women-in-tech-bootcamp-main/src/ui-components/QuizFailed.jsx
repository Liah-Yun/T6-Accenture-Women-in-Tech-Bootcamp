/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function QuizFailed(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="1157px"
      height="433px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "QuizFailed")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="98.84%"
        bottom="-212.7%"
        left="0%"
        right="63.01%"
        transformOrigin="top left"
        transform="rotate(-89.7deg)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Fail Page")}
      >
        <View
          width="720px"
          height="46px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="789.75px"
          left="432.14px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 6")}
        ></View>
        <View
          width="445px"
          height="126px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="238.12px"
          left="359.25px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(206,72,42,1)"
          {...getOverrideProps(overrides, "Rectangle 8")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="18px"
          fontWeight="600"
          color="rgba(255,255,255,1)"
          lineHeight="30px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0px"
          width="343px"
          height="191px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="290.28px"
          left="329.52px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Not all answers are correct, please review the learnings and try again "
          {...getOverrideProps(
            overrides,
            "Not all answers are correct, please review the learnings and try again"
          )}
        ></Text>
        <View
          width="214px"
          height="90px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="203.04px"
          left="183.06px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(252,197,26,1)"
          {...getOverrideProps(overrides, "Rectangle 2125405")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          lineHeight="20px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          width="159px"
          height="65px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="230.17px"
          left="158.2px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="BACK TO LEVEL LEARNINGS PAGE"
          {...getOverrideProps(overrides, "BACK TO LEVEL LEARNINGS PAGE")}
        ></Text>
        <View
          width="214px"
          height="90px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="509.04px"
          left="184.66px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          borderRadius="20px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 2125406")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="600"
          color="rgba(255,255,255,1)"
          lineHeight="20px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          width="119px"
          height="65px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="556.17px"
          left="159.91px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="BACK TO HOMESCREEN"
          {...getOverrideProps(overrides, "BACK TO HOMESCREEN")}
        ></Text>
        <View
          width="926px"
          height="32px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="-0.24px"
          left="428px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 26")}
        ></View>
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="6.8px"
          left="421.04px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 11")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="61.17px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25512")}
          >
            <View
              width="50.6px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(206,72,42,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(206,72,42,1)"
              {...getOverrideProps(overrides, "Rectangle25513")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="45.17px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="4.47px"
              left="16px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="EXIT"
              {...getOverrideProps(overrides, "EXIT")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="797.81px"
          left="421.18px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 12")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="117.25px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button58544")}
          >
            <View
              width="116.77px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(88,204,2,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(88,204,2,1)"
              {...getOverrideProps(overrides, "Rectangle58545")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="104.25px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="6px"
              left="13px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="RETURN TO HOMEPAGE"
              {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
            ></Text>
          </View>
        </View>
      </View>
      <Image
        width="31.98%"
        height="75.98%"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="24.02%"
        bottom="0%"
        left="68.02%"
        right="0%"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(overrides, "she_with_phone 3")}
      ></Image>
    </View>
  );
}
