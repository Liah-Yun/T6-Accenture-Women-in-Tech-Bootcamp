/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, View } from "@aws-amplify/ui-react";
export default function Progressbar5(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="604px"
      height="35px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Progressbar5")}
      {...rest}
    >
      <View
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="25.71%"
        bottom="25.71%"
        left="0%"
        right="2.81%"
        borderRadius="30px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(240,240,240,1)"
        {...getOverrideProps(overrides, "Rectangle 6")}
      ></View>
      <View
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="25.71%"
        bottom="25.71%"
        left="0%"
        right="2.81%"
        borderRadius="30px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 7")}
      ></View>
      <Icon
        width="34px"
        height="35px"
        viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
        paths={[
          {
            d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
            fill: "rgba(252,197,26,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="94.37%"
        right="0%"
        {...getOverrideProps(overrides, "Star 1")}
      ></Icon>
    </View>
  );
}
