/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz05OverridesProps = {
    Quiz05?: PrimitiveOverrideProps<ViewProps>;
    "Group 10"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625379"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625357"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 21"?: PrimitiveOverrideProps<ViewProps>;
    "Superannuation guarantee is a government program that guarantees a minimum annual return on your investments in the stock market"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25364?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25365?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    Character_1_Standing?: PrimitiveOverrideProps<ImageProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 26"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 27"?: PrimitiveOverrideProps<ViewProps>;
    TRUE?: PrimitiveOverrideProps<TextProps>;
    FALSE?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 30"?: PrimitiveOverrideProps<ViewProps>;
    "Group 11"?: PrimitiveOverrideProps<ViewProps>;
    Button25508?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25509?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 15"?: PrimitiveOverrideProps<ViewProps>;
    Button58540?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58541?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type Quiz05Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz05OverridesProps | undefined | null;
}>;
export default function Quiz05(props: Quiz05Props): React.ReactElement;
