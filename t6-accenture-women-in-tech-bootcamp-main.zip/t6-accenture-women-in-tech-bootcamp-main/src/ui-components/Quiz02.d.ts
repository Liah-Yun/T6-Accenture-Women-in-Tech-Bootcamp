/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type Quiz02OverridesProps = {
    "16"?: PrimitiveOverrideProps<TextProps>;
    "18"?: PrimitiveOverrideProps<TextProps>;
    "21"?: PrimitiveOverrideProps<TextProps>;
    "30"?: PrimitiveOverrideProps<TextProps>;
    Quiz02?: PrimitiveOverrideProps<ViewProps>;
    "Quiz 2"?: PrimitiveOverrideProps<ViewProps>;
    "Group 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625217"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 7"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 625252"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 21"?: PrimitiveOverrideProps<ViewProps>;
    "What is the minimum age to be entitled for Super?"?: PrimitiveOverrideProps<TextProps>;
    "Group 6"?: PrimitiveOverrideProps<ViewProps>;
    Button25260?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25261?: PrimitiveOverrideProps<ViewProps>;
    "Next Question"?: PrimitiveOverrideProps<TextProps>;
    "Star 1"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 6"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 7"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 8"?: PrimitiveOverrideProps<IconProps>;
    "Ellipse 9"?: PrimitiveOverrideProps<IconProps>;
    "Rectangle 26"?: PrimitiveOverrideProps<ViewProps>;
    "he_sitting_with_notebook 3"?: PrimitiveOverrideProps<ImageProps>;
    "Group 10"?: PrimitiveOverrideProps<ViewProps>;
    Button25495?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25496?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 12"?: PrimitiveOverrideProps<ViewProps>;
    Button58528?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58529?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 22"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 23"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 24"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 25"?: PrimitiveOverrideProps<ViewProps>;
} & EscapeHatchProps;
export declare type Quiz02Props = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: Quiz02OverridesProps | undefined | null;
}>;
export default function Quiz02(props: Quiz02Props): React.ReactElement;
