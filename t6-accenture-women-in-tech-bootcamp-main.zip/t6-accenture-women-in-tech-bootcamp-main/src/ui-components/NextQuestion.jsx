/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function NextQuestion(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="156.4px"
      height="34.61px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "NextQuestion")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="156.4px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="0%"
        {...getOverrideProps(overrides, "Button")}
      >
        <View
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          border="1px SOLID rgba(109,199,249,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="8px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="67.85px"
          height="11.75px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="33.96%"
          bottom="32.08%"
          left="28.31%"
          right="28.31%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Next Question "
          {...getOverrideProps(overrides, "Next Question")}
        ></Text>
      </View>
    </View>
  );
}
