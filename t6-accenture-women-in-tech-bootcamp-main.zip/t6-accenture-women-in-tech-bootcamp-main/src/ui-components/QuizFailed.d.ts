/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { ImageProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type QuizFailedOverridesProps = {
    QuizFailed?: PrimitiveOverrideProps<ViewProps>;
    "Fail Page"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 6"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 8"?: PrimitiveOverrideProps<ViewProps>;
    "Not all answers are correct, please review the learnings and try again"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 2125405"?: PrimitiveOverrideProps<ViewProps>;
    "BACK TO LEVEL LEARNINGS PAGE"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 2125406"?: PrimitiveOverrideProps<ViewProps>;
    "BACK TO HOMESCREEN"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 26"?: PrimitiveOverrideProps<ViewProps>;
    "Group 11"?: PrimitiveOverrideProps<ViewProps>;
    Button25512?: PrimitiveOverrideProps<ViewProps>;
    Rectangle25513?: PrimitiveOverrideProps<ViewProps>;
    EXIT?: PrimitiveOverrideProps<TextProps>;
    "Group 12"?: PrimitiveOverrideProps<ViewProps>;
    Button58544?: PrimitiveOverrideProps<ViewProps>;
    Rectangle58545?: PrimitiveOverrideProps<ViewProps>;
    "RETURN TO HOMEPAGE"?: PrimitiveOverrideProps<TextProps>;
    "she_with_phone 3"?: PrimitiveOverrideProps<ImageProps>;
} & EscapeHatchProps;
export declare type QuizFailedProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: QuizFailedOverridesProps | undefined | null;
}>;
export default function QuizFailed(props: QuizFailedProps): React.ReactElement;
