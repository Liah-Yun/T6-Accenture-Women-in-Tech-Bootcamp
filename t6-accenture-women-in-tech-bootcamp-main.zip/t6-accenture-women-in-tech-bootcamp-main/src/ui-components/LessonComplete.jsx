/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function LessonComplete(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="696px"
      height="354px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "LessonComplete")}
      {...rest}
    >
      <View
        width="214px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="73.73%"
        bottom="0.85%"
        left="69.25%"
        right="0%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(88,204,2,1)"
        {...getOverrideProps(overrides, "Rectangle 27")}
      ></View>
      <View
        width="397px"
        height="126px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="29.66%"
        bottom="34.75%"
        left="24.86%"
        right="18.1%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(252,197,26,1)"
        {...getOverrideProps(overrides, "Rectangle 8")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="18px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="30px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        letterSpacing="0px"
        width="286px"
        height="191px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="37.01%"
        bottom="9.04%"
        left="32.9%"
        right="26.01%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Congratulations! You have unlocked a new level "
        {...getOverrideProps(
          overrides,
          "Congratulations! You have unlocked a new level"
        )}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="600"
        color="rgba(255,255,255,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="119px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="80.79%"
        bottom="0.85%"
        left="76.01%"
        right="6.9%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="GO TO NEW&#x2028;LEVEL"
        {...getOverrideProps(overrides, "GO TO NEW\u2028LEVEL")}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="16.38%"
        bottom="78.81%"
        left="9.63%"
        right="6.03%"
        {...getOverrideProps(overrides, "Group 1")}
      >
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(240,240,240,1)"
          {...getOverrideProps(overrides, "Rectangle 6")}
        ></View>
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 7")}
        ></View>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="484px"
        height="62px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="82.49%"
        left="20.98%"
        right="9.48%"
        {...getOverrideProps(overrides, "Group 4")}
      >
        <Text
          fontFamily="Inter"
          fontSize="25px"
          fontWeight="600"
          color="rgba(43,175,231,1)"
          textTransform="capitalize"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="484px"
          height="62px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Lesson 1 : What is Superannuation"
          {...getOverrideProps(overrides, "Lesson 1 : What is Superannuation")}
        ></Text>
      </View>
      <View
        width="128px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="73.73%"
        bottom="0.85%"
        left="0%"
        right="81.61%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(243,243,243,1)"
        {...getOverrideProps(overrides, "Rectangle 26")}
      ></View>
      <View
        width="128px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="73.73%"
        bottom="0.85%"
        left="20.98%"
        right="60.63%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 29")}
      ></View>
      <View
        width="125px"
        height="90px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="73.73%"
        bottom="0.85%"
        left="41.95%"
        right="40.09%"
        boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
        borderRadius="20px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(43,175,231,1)"
        {...getOverrideProps(overrides, "Rectangle 28")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(0,0,0,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="81.64%"
        bottom="0%"
        left="1.44%"
        right="83.62%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="BACK TO HOMEPAGE"
        {...getOverrideProps(overrides, "BACK TO HOMEPAGE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(0,0,0,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="80.79%"
        bottom="0.85%"
        left="22.56%"
        right="62.5%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="TAKE ME TO&#xA; ATO WEBSITE"
        {...getOverrideProps(overrides, "TAKE ME TO ATO WEBSITE")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="12px"
        fontWeight="700"
        color="rgba(255,255,255,1)"
        lineHeight="20px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="104px"
        height="65px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="81.36%"
        bottom="0.28%"
        left="43.25%"
        right="41.81%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="RETAKE &#xA;QUIZ"
        {...getOverrideProps(overrides, "RETAKE QUIZ")}
      ></Text>
    </View>
  );
}
