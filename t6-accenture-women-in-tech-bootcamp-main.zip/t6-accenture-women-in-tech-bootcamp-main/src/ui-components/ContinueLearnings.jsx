/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function ContinueLearnings(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="360px"
      height="34.61px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "ContinueLearnings")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="173.12px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="51.91%"
        right="0%"
        {...getOverrideProps(overrides, "Button25415")}
      >
        <View
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="9.65%"
          border="1px SOLID rgba(229,229,229,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(255,255,255,1)"
          {...getOverrideProps(overrides, "Rectangle25416")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="8px"
          fontWeight="700"
          color="rgba(28,176,246,1)"
          textTransform="uppercase"
          lineHeight="0px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="164px"
          height="12px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="34.67%"
          bottom="30.66%"
          left="5.27%"
          right="0%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Continue to NEXT LEARNING"
          {...getOverrideProps(overrides, "Continue to NEXT LEARNING")}
        ></Text>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="156.4px"
        height="34.61px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="0%"
        left="0%"
        right="56.55%"
        {...getOverrideProps(overrides, "Button25418")}
      >
        <View
          width="156.4px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          border="1px SOLID rgba(109,199,249,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle25419")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="8px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          textTransform="uppercase"
          lineHeight="0px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          width="102px"
          height="12px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="34.67%"
          bottom="30.66%"
          left="21.1%"
          right="13.69%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="PREVIOUS LEARNING"
          {...getOverrideProps(overrides, "PREVIOUS LEARNING")}
        ></Text>
      </View>
    </View>
  );
}
