/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type TrueOrFalseOverridesProps = {
    TrueOrFalse?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 2125199"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 2125201"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 22"?: PrimitiveOverrideProps<ViewProps>;
    "Superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire"?: PrimitiveOverrideProps<TextProps>;
    TRUE?: PrimitiveOverrideProps<TextProps>;
    FALSE?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type TrueOrFalseProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: TrueOrFalseOverridesProps | undefined | null;
}>;
export default function TrueOrFalse(props: TrueOrFalseProps): React.ReactElement;
