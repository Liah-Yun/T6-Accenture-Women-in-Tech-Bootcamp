/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, View } from "@aws-amplify/ui-react";
export default function Progressbar1(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="35.18px"
      height="607.11px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Progressbar1")}
      {...rest}
    >
      <View
        padding="0px 0px 0px 0px"
        width="587px"
        height="17px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="0%"
        bottom="97.2%"
        left="54.01%"
        right="-1622.69%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Group 1")}
      >
        <View
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(240,240,240,1)"
          {...getOverrideProps(overrides, "Rectangle 6")}
        ></View>
        <View
          width="107.41px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="81.7%"
          borderRadius="30px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle 7")}
        ></View>
      </View>
      <Icon
        width="34px"
        height="35px"
        viewBox={{ minX: 0, minY: 0, width: 34, height: 35 }}
        paths={[
          {
            d: "M17 0L20.8167 12.0922L33.168 12.0922L23.1756 19.5656L26.9923 31.6578L17 24.1844L7.00765 31.6578L10.8244 19.5656L0.832039 12.0922L13.1833 12.0922L17 0Z",
            fill: "rgba(252,197,26,1)",
            fillRule: "nonzero",
          },
        ]}
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="94.37%"
        bottom="-0.13%"
        left="99.49%"
        right="-96.15%"
        transformOrigin="top left"
        transform="rotate(89.7deg)"
        {...getOverrideProps(overrides, "Star 1")}
      ></Icon>
    </View>
  );
}
