/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Text, View } from "@aws-amplify/ui-react";
export default function Onboardingregdetails(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="311px"
      height="560px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Onboardingregdetails")}
      {...rest}
    >
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="36.79%"
        bottom="56.25%"
        left="2.89%"
        right="8.04%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 7")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="30.89%"
        bottom="63.21%"
        left="2.89%"
        right="12.22%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Annual Income?"
        {...getOverrideProps(overrides, "What is your Annual Income?")}
      ></Text>
      <View
        width="115px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="17.32%"
        bottom="75.71%"
        left="2.89%"
        right="60.13%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 8")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="11.43%"
        bottom="82.68%"
        left="2.89%"
        right="0%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Age?"
        {...getOverrideProps(overrides, "What is your Age?")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="56.25%"
        bottom="36.79%"
        left="2.89%"
        right="8.04%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 9")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="50.36%"
        bottom="43.75%"
        left="2.89%"
        right="0%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Current Super Balance?"
        {...getOverrideProps(overrides, "What is your Current Super Balance?")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="75.36%"
        bottom="17.68%"
        left="2.89%"
        right="8.04%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 11")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="68.04%"
        bottom="26.07%"
        left="2.89%"
        right="0%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Current Employer Contribution?"
        {...getOverrideProps(
          overrides,
          "What is your Current Employer Contribution?"
        )}
      ></Text>
      <View
        width="51px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="93.04%"
        bottom="0%"
        left="2.89%"
        right="80.71%"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 10")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="87.14%"
        bottom="6.96%"
        left="2.89%"
        right="0%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Desired Retirement Age?"
        {...getOverrideProps(overrides, "Desired Retirement Age?")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="24px"
        fontWeight="700"
        color="rgba(43,175,231,1)"
        lineHeight="29.045454025268555px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="270px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="0%"
        bottom="92.5%"
        left="0%"
        right="13.18%"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="ENTER YOUR DETAILS"
        {...getOverrideProps(overrides, "ENTER YOUR DETAILS")}
      ></Text>
    </View>
  );
}
