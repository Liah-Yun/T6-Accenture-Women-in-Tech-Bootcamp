/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Image, Text, View } from "@aws-amplify/ui-react";
export default function DetailsPage(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="428px"
      height="926px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      overflow="hidden"
      position="relative"
      padding="0px 0px 0px 0px"
      backgroundColor="rgba(255,255,255,1)"
      {...getOverrideProps(overrides, "DetailsPage")}
      {...rest}
    >
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="288px"
        left="88px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 7")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="264px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="255px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Annual Income?"
        {...getOverrideProps(overrides, "What is your Annual Income?")}
      ></Text>
      <View
        width="115px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="179px"
        left="88px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 8")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="146px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Age?"
        {...getOverrideProps(overrides, "What is your Age?")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="397px"
        left="88px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 9")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="364px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Current Super Balance?"
        {...getOverrideProps(overrides, "What is your Current Super Balance?")}
      ></Text>
      <View
        width="277px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="504px"
        left="88px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 11")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="463px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="What is your Current Employer Contribution?"
        {...getOverrideProps(
          overrides,
          "What is your Current Employer Contribution?"
        )}
      ></Text>
      <View
        width="51px"
        height="39px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="603px"
        left="88px"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(225,239,247,1)"
        {...getOverrideProps(overrides, "Rectangle 10")}
      ></View>
      <Text
        fontFamily="Inter"
        fontSize="16px"
        fontWeight="400"
        color="rgba(0,0,0,1)"
        lineHeight="19.363636016845703px"
        textAlign="left"
        display="block"
        direction="column"
        justifyContent="unset"
        width="302px"
        height="33px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="570px"
        left="88px"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="Desired Retirement Age?"
        {...getOverrideProps(overrides, "Desired Retirement Age?")}
      ></Text>
      <Text
        fontFamily="Inter"
        fontSize="24px"
        fontWeight="700"
        color="rgba(43,175,231,1)"
        lineHeight="29.045454025268555px"
        textAlign="center"
        display="block"
        direction="column"
        justifyContent="unset"
        width="270px"
        height="42px"
        gap="unset"
        alignItems="unset"
        position="absolute"
        top="82px"
        left="calc(50% - 135px - 0px)"
        padding="0px 0px 0px 0px"
        whiteSpace="pre-wrap"
        children="ENTER YOUR DETAILS"
        {...getOverrideProps(overrides, "ENTER YOUR DETAILS")}
      ></Text>
      <View
        padding="0px 0px 0px 0px"
        width="306.23px"
        height="53px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="682px"
        left="74px"
        {...getOverrideProps(overrides, "Group 8")}
      >
        <View
          width="306.23px"
          height="53px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0px"
          left="0px"
          border="2px SOLID rgba(109,199,249,1)"
          boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
          borderRadius="12px"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(43,175,231,1)"
          {...getOverrideProps(overrides, "Rectangle")}
        ></View>
        <Text
          fontFamily="Inter"
          fontSize="20px"
          fontWeight="700"
          color="rgba(255,255,255,1)"
          textTransform="uppercase"
          lineHeight="18px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="149.74px"
          height="unset"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="18px"
          left="78px"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="next"
          {...getOverrideProps(overrides, "next")}
        ></Text>
      </View>
      <Image
        width="29px"
        height="69px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="801px"
        left="214px"
        padding="0px 0px 0px 0px"
        objectFit="cover"
        {...getOverrideProps(
          overrides,
          "Professional Financial Investment Company and Success Symbol Logo 2"
        )}
      ></Image>
    </View>
  );
}
