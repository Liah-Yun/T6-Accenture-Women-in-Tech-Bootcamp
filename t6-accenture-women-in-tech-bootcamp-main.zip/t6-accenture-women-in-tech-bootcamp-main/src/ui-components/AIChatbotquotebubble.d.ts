/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

import * as React from "react";
import { EscapeHatchProps } from "@aws-amplify/ui-react/internal";
import { IconProps, TextProps, ViewProps } from "@aws-amplify/ui-react";
export declare type PrimitiveOverrideProps<T> = Partial<T> & React.DOMAttributes<HTMLDivElement>;
export declare type AIChatbotquotebubbleOverridesProps = {
    AIChatbotquotebubble?: PrimitiveOverrideProps<ViewProps>;
    "Group 7"?: PrimitiveOverrideProps<ViewProps>;
    "Group 8"?: PrimitiveOverrideProps<ViewProps>;
    "Rectangle 858609"?: PrimitiveOverrideProps<IconProps>;
    "Polygon 158610"?: PrimitiveOverrideProps<IconProps>;
    "I\u2019m just about to get my first job, what should I know about Super?"?: PrimitiveOverrideProps<TextProps>;
    "Rectangle 858602"?: PrimitiveOverrideProps<IconProps>;
    "Polygon 158603"?: PrimitiveOverrideProps<IconProps>;
    "Hi, I\u2019m your SuperSavvy AI Assist, Please type in any question you have about superannuation :)"?: PrimitiveOverrideProps<TextProps>;
} & EscapeHatchProps;
export declare type AIChatbotquotebubbleProps = React.PropsWithChildren<Partial<ViewProps> & {
    overrides?: AIChatbotquotebubbleOverridesProps | undefined | null;
}>;
export default function AIChatbotquotebubble(props: AIChatbotquotebubbleProps): React.ReactElement;
