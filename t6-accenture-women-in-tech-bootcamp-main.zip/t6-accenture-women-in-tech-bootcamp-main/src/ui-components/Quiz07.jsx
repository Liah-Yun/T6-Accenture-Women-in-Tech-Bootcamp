/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import * as React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Icon, Image, Text, View } from "@aws-amplify/ui-react";
export default function Quiz07(props) {
  const { overrides, ...rest } = props;
  return (
    <View
      width="928.23px"
      height="432.84px"
      display="block"
      gap="unset"
      alignItems="unset"
      justifyContent="unset"
      position="relative"
      padding="0px 0px 0px 0px"
      {...getOverrideProps(overrides, "Quiz07")}
      {...rest}
    >
      <View
        width="428px"
        height="926px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        overflow="hidden"
        position="absolute"
        top="98.88%"
        bottom="-212.81%"
        left="0%"
        right="53.89%"
        transformOrigin="top left"
        transform="rotate(-89.7deg)"
        padding="0px 0px 0px 0px"
        backgroundColor="rgba(255,255,255,1)"
        {...getOverrideProps(overrides, "Resource Page")}
      >
        <View
          width="720px"
          height="46px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="789.75px"
          left="432.14px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 625411")}
        ></View>
        <View
          padding="0px 0px 0px 0px"
          width="360px"
          height="34.61px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="308.6px"
          left="77.61px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 6")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="173.12px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="186.88px"
            {...getOverrideProps(overrides, "Button25415")}
          >
            <View
              width="156.4px"
              height="34.61px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(229,229,229,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(255,255,255,1)"
              {...getOverrideProps(overrides, "Rectangle25416")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(28,176,246,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              letterSpacing="0.65px"
              width="164px"
              height="12px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="12px"
              left="9.12px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="Continue to NEXT LEARNING"
              {...getOverrideProps(overrides, "Continue to NEXT LEARNING")}
            ></Text>
          </View>
          <View
            padding="0px 0px 0px 0px"
            width="156.4px"
            height="34.61px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25418")}
          >
            <View
              width="156.4px"
              height="34.61px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(109,199,249,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(43,175,231,1)"
              {...getOverrideProps(overrides, "Rectangle25419")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="102px"
              height="12px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="12px"
              left="33px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="PREVIOUS LEARNING"
              {...getOverrideProps(overrides, "PREVIOUS LEARNING")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="587px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="193.21px"
          left="342.01px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 1")}
        >
          <View
            width="587px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(240,240,240,1)"
            {...getOverrideProps(overrides, "Rectangle 625422")}
          ></View>
          <View
            width="107.41px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            borderRadius="30px"
            padding="0px 0px 0px 0px"
            backgroundColor="rgba(43,175,231,1)"
            {...getOverrideProps(overrides, "Rectangle 7")}
          ></View>
        </View>
        <View
          width="926px"
          height="32px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="-0.24px"
          left="428px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          boxShadow="0px 4px 4px rgba(0, 0, 0, 0.25)"
          padding="0px 0px 0px 0px"
          backgroundColor="rgba(237,237,237,1)"
          {...getOverrideProps(overrides, "Rectangle 27")}
        ></View>
        <Image
          width="93px"
          height="281px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="69.5px"
          left="287.36px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          {...getOverrideProps(overrides, "Character_4_Standing")}
        ></Image>
        <View
          padding="0px 0px 0px 0px"
          width="61.17px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="7.8px"
          left="421.04px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 12")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="61.17px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button25516")}
          >
            <View
              width="50.6px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(206,72,42,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(206,72,42,1)"
              {...getOverrideProps(overrides, "Rectangle25517")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="45.17px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="4.47px"
              left="16px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="EXIT"
              {...getOverrideProps(overrides, "EXIT")}
            ></Text>
          </View>
        </View>
        <View
          padding="0px 0px 0px 0px"
          width="117.25px"
          height="17px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="796.81px"
          left="421.17px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          {...getOverrideProps(overrides, "Group 13")}
        >
          <View
            padding="0px 0px 0px 0px"
            width="117.25px"
            height="17px"
            display="block"
            gap="unset"
            alignItems="unset"
            justifyContent="unset"
            position="absolute"
            top="0px"
            left="0px"
            {...getOverrideProps(overrides, "Button58548")}
          >
            <View
              width="116.77px"
              height="17px"
              display="block"
              gap="unset"
              alignItems="unset"
              justifyContent="unset"
              position="absolute"
              top="0px"
              left="0px"
              border="1px SOLID rgba(88,204,2,1)"
              boxShadow="0px 2px 0px rgba(0.8980392217636108, 0.8980392217636108, 0.8980392217636108, 1)"
              borderRadius="12px"
              padding="0px 0px 0px 0px"
              backgroundColor="rgba(88,204,2,1)"
              {...getOverrideProps(overrides, "Rectangle58549")}
            ></View>
            <Text
              fontFamily="Inter"
              fontSize="8px"
              fontWeight="700"
              color="rgba(255,255,255,1)"
              textTransform="uppercase"
              lineHeight="0px"
              textAlign="left"
              display="block"
              direction="column"
              justifyContent="unset"
              width="104.25px"
              height="5.71px"
              gap="unset"
              alignItems="unset"
              position="absolute"
              top="6px"
              left="13px"
              padding="0px 0px 0px 0px"
              whiteSpace="pre-wrap"
              children="RETURN TO HOMEPAGE"
              {...getOverrideProps(overrides, "RETURN TO HOMEPAGE")}
            ></Text>
          </View>
        </View>
        <Image
          width="29px"
          height="69px"
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="790.02px"
          left="380.14px"
          transformOrigin="top left"
          transform="rotate(89.7deg)"
          padding="0px 0px 0px 0px"
          objectFit="cover"
          {...getOverrideProps(
            overrides,
            "Professional Financial Investment Company and Success Symbol Logo 2"
          )}
        ></Image>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="450px"
        height="62px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="6.47%"
        bottom="79.21%"
        left="31.35%"
        right="20.17%"
        {...getOverrideProps(overrides, "Group 2")}
      >
        <Text
          fontFamily="Inter"
          fontSize="25px"
          fontWeight="600"
          color="rgba(43,175,231,1)"
          textTransform="capitalize"
          lineHeight="18px"
          textAlign="left"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="450px"
          height="62px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="0%"
          right="0%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="Lesson 1 : What is Superannuation"
          {...getOverrideProps(overrides, "Lesson 1 : What is Superannuation")}
        ></Text>
      </View>
      <View
        padding="0px 0px 0px 0px"
        width="467px"
        height="193px"
        display="block"
        gap="unset"
        alignItems="unset"
        justifyContent="unset"
        position="absolute"
        top="30.03%"
        bottom="25.38%"
        left="21.22%"
        right="28.47%"
        {...getOverrideProps(overrides, "Group 3")}
      >
        <Icon
          width="415.67px"
          height="193px"
          viewBox={{ minX: 0, minY: 0, width: 415.67431640625, height: 193 }}
          paths={[
            {
              d: "M1.11672e-14 39.9954C8.27869e-15 17.9041 17.9086 0 40 0L375.674 0C397.766 0 415.674 17.9086 415.674 40L415.674 153C415.674 175.091 397.766 193 375.674 193L40 193C17.9086 193 -1.52616e-14 175.124 -1.0742e-14 153.033C-8.93763e-15 144.213 -5.57729e-15 133.478 0 120.419C1.31078e-14 89.7267 1.39703e-14 61.4339 1.11672e-14 39.9954Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="0%"
          bottom="0%"
          left="10.99%"
          right="0%"
          {...getOverrideProps(overrides, "Rectangle 8")}
        ></Icon>
        <Icon
          width="52.86px"
          height="62.48px"
          viewBox={{
            minX: 0,
            minY: 0,
            width: 62.998046875,
            height: 53.626708984375,
          }}
          paths={[
            {
              d: "M26.2526 4.16178C27.8964 27.3844 31.8218 40.25 52.8565 62.476L0 62.476C0 62.476 24.6089 -19.0609 26.2526 4.16178Z",
              fill: "rgba(225,239,247,1)",
              fillRule: "nonzero",
            },
          ]}
          display="block"
          gap="unset"
          alignItems="unset"
          justifyContent="unset"
          position="absolute"
          top="64.2%"
          bottom="3.43%"
          left="0.11%"
          right="88.57%"
          transformOrigin="top left"
          transform="rotate(-90.57deg)"
          {...getOverrideProps(overrides, "Polygon 1")}
        ></Icon>
        <Text
          fontFamily="Inter"
          fontSize="12px"
          fontWeight="500"
          color="rgba(0,0,0,1)"
          textTransform="capitalize"
          lineHeight="25px"
          textAlign="center"
          display="block"
          direction="column"
          justifyContent="unset"
          letterSpacing="0.65px"
          width="390.69px"
          height="112.87px"
          gap="unset"
          alignItems="unset"
          position="absolute"
          top="21.24%"
          bottom="20.28%"
          left="13.7%"
          right="2.64%"
          padding="0px 0px 0px 0px"
          whiteSpace="pre-wrap"
          children="“Building your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow?”"
          {...getOverrideProps(
            overrides,
            "\u201CBuilding your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow?\u201D"
          )}
        ></Text>
      </View>
    </View>
  );
}
