import React from 'react';
import '../styles/Quiz.css';
import Navbar from '../components/Navbar';
import girl2 from '../Assets/HumanGirl2.png';

const Quiz5 = () => {

    return(

        <div>
            <Navbar />

            <div className='ExitButton'>
                <a className="Button-exit" href='http://localhost:3001/lessons' >Exit Quiz</a>
            </div>

            <div className='quiz-page'>  

                <div>
                    <img src={girl2} alt='girl2'/>
                </div>


                <div className='card'>
                <div className='card-header'>
                    <h2>Question 5</h2>
                </div>

                <div className='question-content'>
                    <div className='question'>
                        <p>What does ATO stand for</p>
                    </div>

                    <div className='gridbox'>

                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Australian Trade Organization</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>All Things Organic</a> </td>
                        </tr>
                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Association of Taxpayers Online</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizcompleted'> Australian Taxation Office</a> </td>
                        </tr>
                    </div>
                </div>
                </div>
            </div>
        </div>
    );
};

export default Quiz5;