import React from 'react';
import '../styles/App.css';
import Navbar from '../components/Navbar';

const Signup = () => {

    return(

        <div>
            <Navbar />
            <h1>Signup</h1>
        </div>
    );
};

export default Signup;