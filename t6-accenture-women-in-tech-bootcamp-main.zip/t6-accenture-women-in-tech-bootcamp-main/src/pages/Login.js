import React from 'react';
import '../styles/App.css';
import Navbar from '../components/Navbar';

const Login = () => {

    return(

        <div>
            <Navbar />
            <h1>Login</h1>
        </div>
    );
};

export default Login;