import React from 'react';
import '../styles/Quizfailed.css';
import Navbar from '../components/Navbar';
import girl1 from '../Assets/HumanGirl1.png';

const Quizfailed = () => {

    return(

        <div>
            <Navbar />
            <div className='FailedPage'>
                <div>
                    <img src={girl1} alt='girl1'/>
                </div>

                <div className='FailedBubble'>
                    <div className='text-bubble'>
                        <p>Oh no! That was an incorrect answer <br />That's okay, click below to try again!</p>
                    </div>

                    <div className='startbuttons'>

                        <a className='Button1-3' href='http://localhost:3001/quiz1'>Retry Quiz</a>


                    </div>
                </div>
            </div>
        </div>
    );
};

export default Quizfailed;