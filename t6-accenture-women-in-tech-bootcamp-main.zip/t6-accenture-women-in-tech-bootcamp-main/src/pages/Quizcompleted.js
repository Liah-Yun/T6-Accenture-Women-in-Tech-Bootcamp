import React from 'react';
import '../styles/Quizcompleted.css';
import Navbar from '../components/Navbar';
import girl1 from '../Assets/HumanGirl1.png';


const Quizcompleted = () => {

    return(

        <div>
            <Navbar />
            <div className='CompletedPage'>
                <div>
                    <img src={girl1} alt='girl1'/>
                </div>

                <div className='CompletedBubble'>
                    <div className='completed-text'>
                        <p>Congratulations! You completed the quiz! <br />You've unlocked level 2!</p>
                    </div>

                    <div className='startbuttons'>

                        <a className='Button1-4' href='http://localhost:3001/levels'>Click here to return to levels</a>

                    </div>

                </div>
            </div>
        </div>
    );
};

export default Quizcompleted;