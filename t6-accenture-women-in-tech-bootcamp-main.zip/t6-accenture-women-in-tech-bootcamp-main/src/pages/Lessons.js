import React from 'react';
import '../styles/Lessons.css';
import Navbar from '../components/Navbar';


const Lessons = () => {

    return(

        <div>

            <Navbar />

            <div className='LessonTitle'>
                <h1>Welcome to your first lesson!</h1>
            </div>


            <div className='LessonPage'>

                <div className='LessonBubble'>
                    <div className='lesson-text'>
                        <p>What is superannuation or super? Isn't that the thing only old people need to worry about? Well, yes and no. Your superannuation is money that you and your employer put into a super fund while you're working so you'll have something to live on when you retire.

                            But! Building your super begins a long, long time before you retire when you start your first job. And it can take your whole working life to grow. So, how does your superannuation actually grow? Once your super fund is set up, every time your employer pays you, they have to pay money into your super fund. All employers are required by law to make super contributions for their employees. This is called the superannuation guarantee.

                            So, if you're 18 or older and you're earning $450 before tax per month, you're entitled to super. If you're under 18, you need to be working at least 30 hours a week and earning $450 before tax per month to be entitled to super. All this might sound a bit complicated, but once it's set up, your super fund will grow without you having to do very much at all. Well, except work of course.

                            One thing to be aware of is that some employers don't pay super or don't pay the correct amount of super to their employees. Employers are legally required to pay the correct amount of super. So, if you think your employer is underpaying your super or is not paying it at all, first check your pay slip, check with your employer, contact your super fund and visit the ATO website. If you're still not convinced they're paying you the correct amount of super, you can report them to the ATO. (that's the Australian Taxation Office).</p>
                    </div>

                    <div className='startbuttons'>

                        <a className='Button1-1' href='http://localhost:3001/homepage'>Return to Dashboard</a>

                        <a className='Button1-2' href='http://localhost:3001/quiz1'>Start Quiz</a>

                    </div>
                </div>
            </div>
        

        </div>
    );
};

export default Lessons;