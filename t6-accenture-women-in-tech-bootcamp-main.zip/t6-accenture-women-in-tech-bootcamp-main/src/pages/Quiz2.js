import React from 'react';
import '../styles/Quiz.css';
import Navbar from '../components/Navbar';
import boy1 from '../Assets/HumanBoy1.png';

const Quiz2 = () => {

    return(

        <div>
            <Navbar />

            <div className='ExitButton'>
                <a className="Button-exit" href='http://localhost:3001/lessons' >Exit Quiz</a>
            </div>

            <div className='quiz-page'>  

                <div>
                    <img src={boy1} alt='boy1'/>
                </div>


                <div className='card'>
                <div className='card-header'>
                    <h2>Question 2</h2>
                </div>

                <div className='question-content'>
                    <div className='question'>
                        <p>How does your superannuation grow over time?</p>
                    </div>

                    <div className='gridbox'>

                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>By privately investing in stocks and bonds</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quiz3'>Through regular contributions from your employer</a> </td>
                        </tr>
                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Through yearly government contributions</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'> By earning lots of money in your career</a> </td>
                        </tr>
                    </div>
                </div>
                </div>
            </div>
        </div>
    );
};

export default Quiz2;