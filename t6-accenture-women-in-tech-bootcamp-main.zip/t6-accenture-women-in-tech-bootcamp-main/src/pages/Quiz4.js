import React from 'react';
import '../styles/Quiz.css';
import Navbar from '../components/Navbar';
import boy2 from '../Assets/HumanBoy2.png';

const Quiz4 = () => {

    return(

        <div>
            <Navbar />

            <div className='ExitButton'>
                <a className="Button-exit" href='http://localhost:3001/lessons' >Exit Quiz</a>
            </div>

            <div className='quiz-page'>  

                <div>
                    <img src={boy2} alt='boy2'/>
                </div>


                <div className='card'>
                <div className='card-header'>
                    <h2>Question 4</h2>
                </div>

                <div className='question-content'>
                    <div className='question'>
                        <p>What should you do if you suspect your employer is <br /> not paying the correct amount of superannuation?</p>
                    </div>

                    <div className='gridbox'>

                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Complain to your coworkers</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Ignore it and hope it gets better</a> </td>
                        </tr>
                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quiz5'>Contact your super fund and visit the ATO website</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'> File a lawsuit against your employer</a> </td>
                        </tr>
                    </div>
                </div>
                </div>
            </div>
        </div>
    );
};

export default Quiz4;