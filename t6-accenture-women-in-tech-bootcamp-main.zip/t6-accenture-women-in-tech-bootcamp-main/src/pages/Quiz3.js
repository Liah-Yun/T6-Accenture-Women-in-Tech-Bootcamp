import React from 'react';
import '../styles/Quiz.css';
import Navbar from '../components/Navbar';
import girl3 from '../Assets/HumanGirl3.png';

const Quiz3 = () => {

    return(

        <div>
            <Navbar />

            <div className='ExitButton'>
                <a className="Button-exit" href='http://localhost:3001/lessons' >Exit Quiz</a>
            </div>

            <div className='quiz-page'>  

                <div>
                    <img src={girl3} alt='girl3'/>
                </div>


                <div className='card'>
                <div className='card-header'>
                    <h2>Question 3</h2>
                </div>

                <div className='question-content'>
                    <div className='question'>
                        <p>Who is entitled to receive superannuation contributions from their employer?</p>
                    </div>

                    <div className='gridbox'>

                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Anyone who is over the age of 21</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quiz4'>Those earning $450 or more before tax per month</a> </td>
                        </tr>
                        <tr>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'>Only those working full time</a> </td>
                            <td> <a className='Button' href='http://localhost:3001/quizfailed'> Only those who are already retired</a> </td>
                        </tr>
                    </div>
                </div>
                </div>
            </div>
        </div>
    );
};

export default Quiz3;