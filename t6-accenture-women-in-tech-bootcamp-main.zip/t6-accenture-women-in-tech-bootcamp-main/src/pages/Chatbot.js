import React from 'react';
import '../styles/App.css';
import Navbar from '../components/Navbar';

const Chatbot = () => {

    return(

        <div>
            <Navbar />
            <h1>Chatbot</h1>
        </div>
    );
};

export default Chatbot;