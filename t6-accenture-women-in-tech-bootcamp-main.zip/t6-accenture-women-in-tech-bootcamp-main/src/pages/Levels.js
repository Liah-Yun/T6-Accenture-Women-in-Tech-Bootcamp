import React from 'react';
import '../styles/App.css';
import Navbar from '../components/Navbar';

const Levels = () => {

    return(

        <div>
            <Navbar />
            <h1>Levels</h1>
        </div>
    );
};

export default Levels;