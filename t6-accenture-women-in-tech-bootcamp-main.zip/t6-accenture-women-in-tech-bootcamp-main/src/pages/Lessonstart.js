import React from 'react';
import '../styles/Lessonstart.css';
import Navbar from '../components/Navbar';
import girl1 from '../Assets/HumanGirl1.png';


const Lessonstart = () => {

    return(

        <div>

            <Navbar />
            <div className='WelcomePage'>
                <div>
                    <img src={girl1} alt='girl1'/>
                </div>

                <div className='WelcomeBubble'>
                    <div className='text-bubble'>
                        <p>Welcome To SuperSavvy, Where You Unlock Your Finanical Future. Start Your Learnings By Clicking Start New Lesson Or You Can Also Resume Previous Lessons</p>
                    </div>

                    <div className='startbuttons'>

                        <a className='Button1-1' href='http://localhost:3001/lessons'>Resume Lesson</a>

                        <a className='Button1-2' href='http://localhost:3001/lessons'>Start New Lesson</a>

                    </div>
                </div>
            </div>
        

        </div>
    );
};

export default Lessonstart;